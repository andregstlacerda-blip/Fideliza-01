export const brl = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

export const formatPhone = (p: string) => {
  const d = (p || '').replace(/\D/g, '').replace(/^55(?=\d{10,11}$)/, '');
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return p;
};

export const maskPhone = (v: string) => {
  const d = v.replace(/\D/g, '').slice(0, 11);
  if (d.length <= 2) return d.length ? `(${d}` : '';
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
};

export const dateBR = (s: string | null) => (s ? new Date(s).toLocaleDateString('pt-BR') : '—');
export const dateTimeBR = (s: string) =>
  new Date(s).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

export const unit = (mode: string, n: number) =>
  mode === 'stamps' ? (n === 1 ? 'carimbo' : 'carimbos') : n === 1 ? 'ponto' : 'pontos';

export const origin = () => window.location.origin;

/** Extrai o token de uma leitura de QR (aceita URL completa ou o código puro). */
export function parseScan(text: string, param: 'cartao' | 'codigo'): string {
  const t = text.trim();
  try {
    const u = new URL(t);
    const q = u.searchParams.get(param);
    if (q) return q;
    const last = u.pathname.split('/').filter(Boolean).pop();
    return last || t;
  } catch {
    return t;
  }
}

import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabaseConfigured = Boolean(url && anonKey && !url.includes('SEU-PROJETO'));

// Apenas a chave ANON (pública) vai para o navegador. Nunca use a service_role aqui.
export const supabase = createClient(url || 'http://localhost', anonKey || 'missing', {
  auth: { persistSession: true, autoRefreshToken: true },
});

export function errMsg(e: unknown): string {
  const m = (e as { message?: string })?.message || 'Algo deu errado. Tente novamente.';
  if (m.includes('Invalid login credentials')) return 'E-mail ou senha incorretos.';
  if (m.includes('User already registered')) return 'Este e-mail já tem conta. Faça login.';
  if (m.includes('Password should be')) return 'A senha precisa ter pelo menos 6 caracteres.';
  if (m.includes('Email not confirmed')) return 'Confirme seu e-mail pelo link que enviamos.';
  if (m.includes('Failed to fetch')) return 'Sem conexão com o servidor. Verifique sua internet.';
  return m;
}

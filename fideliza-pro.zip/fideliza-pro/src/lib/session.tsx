import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from './supabase';

export type Business = {
  id: string; name: string; segment: string | null; phone: string | null; join_code: string;
};
export type Program = {
  id: string; name: string; mode: 'points' | 'stamps'; amount_per_point: number;
  stamps_per_visit: number; welcome_message: string | null; active: boolean;
};
export type License = {
  status: string; max_customers: number; max_staff: number; expires_at: string | null;
};

type Ctx = {
  session: Session | null;
  loading: boolean;
  business: Business | null;
  role: 'owner' | 'staff' | null;
  program: Program | null;
  license: License | null;
  refresh: () => Promise<void>;
  signOut: () => Promise<void>;
};

const SessionCtx = createContext<Ctx>(null as unknown as Ctx);
export const useSession = () => useContext(SessionCtx);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [business, setBusiness] = useState<Business | null>(null);
  const [role, setRole] = useState<'owner' | 'staff' | null>(null);
  const [program, setProgram] = useState<Program | null>(null);
  const [license, setLicense] = useState<License | null>(null);

  const loadBusiness = useCallback(async (s: Session | null) => {
    if (!s) { setBusiness(null); setRole(null); setProgram(null); setLicense(null); return; }
    let { data: m } = await supabase.from('business_members').select('business_id, role').eq('user_id', s.user.id).maybeSingle();
    if (!m) {
      // Funcionário convidado: vincula automaticamente pelo e-mail
      const { data: claimed } = await supabase.rpc('claim_invites');
      if (claimed) {
        ({ data: m } = await supabase.from('business_members').select('business_id, role').eq('user_id', s.user.id).maybeSingle());
      }
    }
    if (!m) { setBusiness(null); setRole(null); setProgram(null); setLicense(null); return; }
    const [b, p, l] = await Promise.all([
      supabase.from('businesses').select('id, name, segment, phone, join_code').eq('id', m.business_id).single(),
      supabase.from('loyalty_programs').select('*').eq('business_id', m.business_id).single(),
      supabase.from('licenses').select('status, max_customers, max_staff, expires_at').eq('business_id', m.business_id).single(),
    ]);
    setBusiness(b.data as Business);
    setProgram(p.data as Program);
    setLicense(l.data as License);
    setRole(m.role as 'owner' | 'staff');
  }, []);

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data }) => {
      setSession(data.session);
      await loadBusiness(data.session);
      setLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((event, s) => {
      setSession(s);
      if (event === 'SIGNED_IN' || event === 'SIGNED_OUT') {
        setLoading(true);
        // fora do callback para evitar deadlock do supabase-js
        setTimeout(() => loadBusiness(s).finally(() => setLoading(false)), 0);
      }
    });
    return () => sub.subscription.unsubscribe();
  }, [loadBusiness]);

  const refresh = useCallback(() => loadBusiness(session), [loadBusiness, session]);
  const signOut = useCallback(async () => { await supabase.auth.signOut(); }, []);

  return (
    <SessionCtx.Provider value={{ session, loading, business, role, program, license, refresh, signOut }}>
      {children}
    </SessionCtx.Provider>
  );
}

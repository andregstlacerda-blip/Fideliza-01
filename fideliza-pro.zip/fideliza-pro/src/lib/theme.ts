export type Theme = 'light' | 'dark';
const KEY = 'fideliza-theme';

export function getTheme(): Theme {
  try {
    const saved = localStorage.getItem(KEY) as Theme | null;
    if (saved === 'light' || saved === 'dark') return saved;
  } catch { /* storage indisponível */ }
  return window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

export function applyTheme(t: Theme) {
  document.documentElement.dataset.theme = t;
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', t === 'dark' ? '#0E0E10' : '#F5F2EC');
  try { localStorage.setItem(KEY, t); } catch { /* ignore */ }
}

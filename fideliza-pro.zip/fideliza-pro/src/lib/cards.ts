// Guarda no aparelho do cliente o link da carteirinha de cada estabelecimento
const KEY = 'fideliza-cards';
type Saved = Record<string, string>; // joinCode -> token

function read(): Saved {
  try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch { return {}; }
}
export function savedCard(joinCode: string): string | null {
  return read()[joinCode.toUpperCase()] || null;
}
export function saveCard(joinCode: string, token: string) {
  try { localStorage.setItem(KEY, JSON.stringify({ ...read(), [joinCode.toUpperCase()]: token })); } catch { /* ignore */ }
}

import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CheckCircle2, Search, UserRound } from 'lucide-react';
import { supabase, errMsg } from '../../lib/supabase';
import { useSession } from '../../lib/session';
import { brl, formatPhone, parseScan, unit } from '../../lib/format';
import Scanner from '../../components/Scanner';
import { Alert, PageHeader, Spinner } from '../../components/ui';

type Target = { token: string; id: string; name: string; phone: string; balance: number };

export default function Earn() {
  const { business, program } = useSession();
  const [params, setParams] = useSearchParams();
  const [target, setTarget] = useState<Target | null>(null);
  const [amount, setAmount] = useState('');
  const [key, setKey] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState<{ points: number; balance: number; name: string } | null>(null);
  const [q, setQ] = useState('');
  const [results, setResults] = useState<{ id: string; name: string; phone: string }[]>([]);

  const selectByToken = useCallback(async (token: string) => {
    setError(''); setDone(null);
    const { data } = await supabase.from('customer_cards').select('token, customers(id, name, phone)').eq('token', token).maybeSingle();
    const c = (data as unknown as { customers?: { id: string; name: string; phone: string } } | null)?.customers;
    if (!data || !c) { setError('Carteirinha não encontrada neste estabelecimento.'); return; }
    const { data: tx } = await supabase.from('point_transactions').select('points').eq('customer_id', c.id);
    const balance = (tx || []).reduce((s, t) => s + t.points, 0);
    setTarget({ token, ...c, balance });
    setKey(crypto.randomUUID());
    setAmount('');
  }, []);

  useEffect(() => {
    const t = params.get('cartao');
    if (t) { selectByToken(t); setParams({}, { replace: true }); }
  }, [params, setParams, selectByToken]);

  async function search(e: FormEvent) {
    e.preventDefault();
    if (!business || q.trim().length < 2) return;
    const { data } = await supabase.rpc('customers_with_balance', { p_business: business.id, p_search: q.trim() });
    setResults((data || []).slice(0, 8));
    if (!data?.length) setError('Nenhum cliente encontrado.'); else setError('');
  }

  async function pick(customerId: string) {
    const { data } = await supabase.from('customer_cards').select('token').eq('customer_id', customerId).single();
    setResults([]); setQ('');
    if (data) selectByToken(data.token);
  }

  async function confirm(e: FormEvent) {
    e.preventDefault();
    if (!target) return;
    setBusy(true); setError('');
    const { data, error } = await supabase.rpc('earn_points', {
      p_card_token: target.token,
      p_amount: program?.mode === 'points' ? Number(amount.replace(/\./g, '').replace(',', '.')) : null,
      p_idempotency_key: key,
    });
    setBusy(false);
    if (error) return setError(errMsg(error));
    const r = data as { points: number; balance: number; customer_name: string };
    setDone({ points: r.points, balance: r.balance, name: r.customer_name });
    setTarget(null);
  }

  if (!program) return null;
  const u = (n: number) => unit(program.mode, n);
  const value = Number(amount.replace(/\./g, '').replace(',', '.')) || 0;
  const preview = program.mode === 'points' ? Math.floor(value / Number(program.amount_per_point)) : program.stamps_per_visit;

  return (
    <>
      <PageHeader title="Pontuar cliente" subtitle={program.mode === 'points'
        ? `1 ponto a cada ${brl(Number(program.amount_per_point))}` : `${program.stamps_per_visit} ${u(program.stamps_per_visit)} por visita`} />

      {done && (
        <div className="card mb-4 flex items-center gap-3 p-5">
          <CheckCircle2 className="shrink-0 text-success" size={28} />
          <div>
            <p className="font-semibold">+{done.points} {u(done.points)} para {done.name}</p>
            <p className="text-sm text-muted">Saldo atual: {done.balance} {u(done.balance)}</p>
          </div>
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <div>
          <Scanner paused={!!target} onScan={(text) => selectByToken(parseScan(text, 'cartao'))} />
          <form onSubmit={search} className="mt-4 flex gap-2">
            <input className="input" placeholder="Ou busque por nome ou telefone" value={q} onChange={(e) => setQ(e.target.value)} />
            <button className="btn btn-ghost shrink-0" aria-label="Buscar"><Search size={18} /></button>
          </form>
          {results.length > 0 && (
            <ul className="card mt-2 divide-y divide-line">
              {results.map((r) => (
                <li key={r.id}><button className="flex w-full justify-between px-4 py-3 text-left text-sm hover:bg-surface-2 cursor-pointer" onClick={() => pick(r.id)}>
                  <span>{r.name}</span><span className="text-muted">{formatPhone(r.phone)}</span></button></li>
              ))}
            </ul>
          )}
        </div>

        <div>
          <Alert>{error}</Alert>
          {target ? (
            <form onSubmit={confirm} className="card space-y-4 p-6">
              <div className="flex items-center gap-3">
                <span className="grid h-11 w-11 place-items-center rounded-full bg-surface-2 text-gold"><UserRound size={20} /></span>
                <div>
                  <p className="font-semibold">{target.name}</p>
                  <p className="text-sm text-muted">{formatPhone(target.phone)} · {target.balance} {u(target.balance)}</p>
                </div>
              </div>
              {program.mode === 'points' && (
                <div>
                  <label className="label" htmlFor="v">Valor da compra (R$)</label>
                  <input id="v" className="input h-14 text-2xl font-semibold" inputMode="decimal" autoFocus required placeholder="0,00"
                    value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^\d,.]/g, ''))} />
                </div>
              )}
              <p className="text-sm text-muted">O cliente vai ganhar <strong className="text-fg">{preview} {u(preview)}</strong>.</p>
              <div className="flex gap-2">
                <button type="button" className="btn btn-ghost" onClick={() => setTarget(null)}>Cancelar</button>
                <button className="btn btn-primary flex-1" disabled={busy || preview < 1}>{busy && <Spinner />} Confirmar</button>
              </div>
            </form>
          ) : (
            <div className="card p-6 text-sm text-muted">
              Escaneie o QR da carteirinha do cliente (na tela do celular dele) ou busque pelo nome.
              Clientes novos se cadastram pelo <strong className="text-fg">QR do balcão</strong>.
            </div>
          )}
        </div>
      </div>
    </>
  );
}

import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Copy, MessageCircle, PlusCircle } from 'lucide-react';
import { supabase, errMsg } from '../../lib/supabase';
import { useSession } from '../../lib/session';
import { brl, dateBR, dateTimeBR, formatPhone, origin, unit } from '../../lib/format';
import { Alert, PageLoader, Spinner } from '../../components/ui';

type Customer = { id: string; name: string; phone: string; email: string | null; birthday: string | null; created_at: string };
type Tx = { id: string; kind: string; points: number; amount: number | null; note: string | null; created_at: string };

export default function CustomerDetail() {
  const { id = '' } = useParams();
  const { business, program, role } = useSession();
  const nav = useNavigate();
  const [c, setC] = useState<Customer | null>(null);
  const [token, setToken] = useState('');
  const [txs, setTxs] = useState<Tx[]>([]);
  const [adj, setAdj] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const [cu, card, tx] = await Promise.all([
      supabase.from('customers').select('id, name, phone, email, birthday, created_at').eq('id', id).maybeSingle(),
      supabase.from('customer_cards').select('token').eq('customer_id', id).maybeSingle(),
      supabase.from('point_transactions').select('id, kind, points, amount, note, created_at').eq('customer_id', id).order('created_at', { ascending: false }).limit(100),
    ]);
    setC(cu.data as Customer); setToken(card.data?.token || ''); setTxs((tx.data as Tx[]) || []);
  }, [id]);
  useEffect(() => { load(); }, [load]);

  if (!c || !program) return <PageLoader />;
  const u = (n: number) => unit(program.mode, n);
  const balance = txs.reduce((s, t) => s + t.points, 0);
  const link = `${origin()}/c/${token}`;
  const wa = `https://wa.me/55${c.phone.replace(/^55/, '')}?text=${encodeURIComponent(`Olá, ${c.name.split(' ')[0]}! Aqui está sua carteirinha de fidelidade da ${business?.name}: ${link}`)}`;

  async function adjust(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setError(''); setMsg('');
    const { error } = await supabase.rpc('adjust_points', { p_customer: c!.id, p_points: parseInt(adj, 10), p_note: note });
    setBusy(false);
    if (error) return setError(errMsg(error));
    setAdj(''); setNote(''); setMsg('Ajuste registrado.'); load();
  }

  async function remove() {
    if (!window.confirm(`Excluir ${c!.name} e todo o histórico? Use apenas se o cliente pedir a exclusão dos dados (LGPD).`)) return;
    const { error } = await supabase.from('customers').delete().eq('id', c!.id);
    if (error) return setError(errMsg(error));
    nav('/app/clientes', { replace: true });
  }

  return (
    <>
      <Link to="/app/clientes" className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted hover:text-fg"><ArrowLeft size={16} /> Clientes</Link>
      <div className="grid gap-4 lg:grid-cols-[1fr_1.2fr]">
        <div className="space-y-4">
          <div className="card p-6">
            <h1 className="text-2xl font-bold">{c.name}</h1>
            <p className="mt-1 text-sm text-muted">{formatPhone(c.phone)}{c.email ? ` · ${c.email}` : ''}</p>
            <p className="mt-1 text-sm text-muted">Cliente desde {dateBR(c.created_at)}{c.birthday ? ` · aniversário ${new Date(c.birthday + 'T12:00').toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}` : ''}</p>
            <p className="mt-5 font-display text-4xl font-extrabold text-gold">{balance} <span className="text-base font-semibold text-muted">{u(balance)}</span></p>
            <div className="mt-5 flex flex-wrap gap-2">
              <Link to={`/app/pontuar?cartao=${token}`} className="btn btn-primary"><PlusCircle size={18} /> Pontuar</Link>
              <a href={wa} target="_blank" rel="noreferrer" className="btn btn-ghost"><MessageCircle size={18} /> Enviar carteirinha</a>
              <button className="btn btn-ghost" onClick={() => { navigator.clipboard?.writeText(link); setMsg('Link copiado.'); }}><Copy size={18} /> Copiar link</button>
            </div>
          </div>
          <Alert kind="success">{msg}</Alert>
          <Alert>{error}</Alert>
          {role === 'owner' && (
            <form onSubmit={adjust} className="card space-y-3 p-6">
              <h2 className="font-bold">Ajuste manual</h2>
              <p className="text-xs text-muted">Para corrigir erros. Use número negativo para remover. Fica registrado no histórico.</p>
              <div className="flex gap-2">
                <input className="input w-28" inputMode="numeric" placeholder="+/-" required value={adj} onChange={(e) => setAdj(e.target.value.replace(/[^\d-]/g, ''))} />
                <input className="input" placeholder="Motivo" required value={note} onChange={(e) => setNote(e.target.value)} />
              </div>
              <button className="btn btn-ghost w-full" disabled={busy}>{busy && <Spinner />} Registrar ajuste</button>
              <button type="button" className="btn btn-danger w-full" onClick={remove}>Excluir cliente (LGPD)</button>
            </form>
          )}
        </div>
        <div className="card p-6">
          <h2 className="font-bold">Histórico</h2>
          {txs.length === 0 ? <p className="mt-3 text-sm text-muted">Nenhuma movimentação.</p> : (
            <ul className="mt-3 divide-y divide-line text-sm">
              {txs.map((t) => (
                <li key={t.id} className="flex justify-between gap-3 py-2.5">
                  <div>
                    <p>{t.kind === 'earn' ? 'Compra' : t.kind === 'redeem' ? `Resgate · ${t.note}` : `Ajuste · ${t.note}`}</p>
                    <p className="text-xs text-muted">{dateTimeBR(t.created_at)}{t.amount ? ` · ${brl(Number(t.amount))}` : ''}</p>
                  </div>
                  <span className={`font-semibold ${t.points > 0 ? 'text-success' : 'text-danger'}`}>{t.points > 0 ? '+' : ''}{t.points}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </>
  );
}

import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Award, Pencil } from 'lucide-react';
import { supabase, errMsg } from '../../lib/supabase';
import { useSession } from '../../lib/session';
import { unit } from '../../lib/format';
import { Alert, Empty, PageHeader, PageLoader, Spinner } from '../../components/ui';

type Reward = { id: string; name: string; description: string | null; cost: number; active: boolean };
const blank = { id: '', name: '', description: '', cost: '' };

export default function Rewards() {
  const { business, program, role } = useSession();
  const [list, setList] = useState<Reward[] | null>(null);
  const [form, setForm] = useState(blank);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const owner = role === 'owner';

  const load = useCallback(async () => {
    if (!business) return;
    const { data } = await supabase.from('rewards').select('*').eq('business_id', business.id).order('cost');
    setList((data as Reward[]) || []);
  }, [business]);
  useEffect(() => { load(); }, [load]);

  async function save(e: FormEvent) {
    e.preventDefault();
    if (!business) return;
    setBusy(true); setError('');
    const row = { name: form.name.trim(), description: form.description.trim() || null, cost: parseInt(form.cost, 10) };
    const { error } = form.id
      ? await supabase.from('rewards').update(row).eq('id', form.id)
      : await supabase.from('rewards').insert({ ...row, business_id: business.id });
    setBusy(false);
    if (error) return setError(errMsg(error));
    setForm(blank); load();
  }

  async function toggle(r: Reward) {
    await supabase.from('rewards').update({ active: !r.active }).eq('id', r.id);
    load();
  }

  if (!list || !program) return <PageLoader />;
  const u = (n: number) => unit(program.mode, n);

  return (
    <>
      <PageHeader title="Recompensas" subtitle={`O que o cliente pode trocar pelos ${u(2)}`} />
      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        <div>
          {list.length === 0 ? (
            <Empty icon={<Award size={22} />} title="Nenhuma recompensa" text={program.mode === 'stamps' ? 'Ex.: "Corte grátis" por 10 carimbos.' : 'Ex.: "Café grátis" por 15 pontos.'} />
          ) : (
            <ul className="card divide-y divide-line">
              {list.map((r) => (
                <li key={r.id} className="flex items-center justify-between gap-3 p-4">
                  <div className={r.active ? '' : 'opacity-50'}>
                    <p className="font-semibold">{r.name}</p>
                    <p className="text-sm text-muted">{r.cost} {u(r.cost)}{r.description ? ` · ${r.description}` : ''}{!r.active ? ' · pausada' : ''}</p>
                  </div>
                  {owner && (
                    <div className="flex shrink-0 gap-2">
                      <button className="btn btn-ghost h-9 px-3" aria-label="Editar" onClick={() => setForm({ id: r.id, name: r.name, description: r.description || '', cost: String(r.cost) })}><Pencil size={16} /></button>
                      <button className="btn btn-ghost h-9" onClick={() => toggle(r)}>{r.active ? 'Pausar' : 'Ativar'}</button>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
        {owner && (
          <form onSubmit={save} className="card h-fit space-y-4 p-6">
            <h2 className="font-bold">{form.id ? 'Editar recompensa' : 'Nova recompensa'}</h2>
            <div>
              <label className="label" htmlFor="rn">Nome</label>
              <input id="rn" className="input" required minLength={2} maxLength={80} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <label className="label" htmlFor="rc">Custo em {u(2)}</label>
              <input id="rc" className="input" inputMode="numeric" required value={form.cost} onChange={(e) => setForm({ ...form, cost: e.target.value.replace(/\D/g, '') })} />
            </div>
            <div>
              <label className="label" htmlFor="rd">Descrição <span className="text-muted">(opcional)</span></label>
              <input id="rd" className="input" maxLength={120} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <Alert>{error}</Alert>
            <div className="flex gap-2">
              {form.id && <button type="button" className="btn btn-ghost" onClick={() => setForm(blank)}>Cancelar</button>}
              <button className="btn btn-primary flex-1" disabled={busy}>{busy && <Spinner />} Salvar</button>
            </div>
          </form>
        )}
      </div>
    </>
  );
}

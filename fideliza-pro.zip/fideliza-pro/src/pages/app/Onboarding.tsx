import { useState, type FormEvent } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { Sparkles, Stamp } from 'lucide-react';
import { supabase, errMsg } from '../../lib/supabase';
import { useSession } from '../../lib/session';
import { maskPhone } from '../../lib/format';
import { Alert, Logo, PageLoader, Spinner, ThemeToggle } from '../../components/ui';

const segments = ['Barbearia', 'Salão de beleza', 'Cafeteria', 'Restaurante', 'Lanchonete', 'Doceria', 'Loja', 'Outro'];

export default function Onboarding() {
  const { session, loading, business, refresh, signOut } = useSession();
  const nav = useNavigate();
  const [name, setName] = useState('');
  const [segment, setSegment] = useState('Barbearia');
  const [phone, setPhone] = useState('');
  const [mode, setMode] = useState<'points' | 'stamps'>('stamps');
  const [amount, setAmount] = useState('10');
  const [busy, setBusy] = useState(false);
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState('');

  if (loading) return <PageLoader />;
  if (!session) return <Navigate to="/entrar" replace />;
  if (business) return <Navigate to="/app" replace />;

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      const { data: bid, error } = await supabase.rpc('create_business', {
        p_name: name, p_segment: segment, p_phone: phone.replace(/\D/g, '') || null,
      });
      if (error) throw error;
      const { error: e2 } = await supabase.from('loyalty_programs')
        .update({ mode, amount_per_point: Number(amount.replace(',', '.')) || 10, stamps_per_visit: 1, updated_at: new Date().toISOString() })
        .eq('business_id', bid);
      if (e2) throw e2;
      await refresh();
      nav('/app', { replace: true });
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  }

  async function checkInvite() {
    setChecking(true);
    await refresh();
    setChecking(false);
    setError('Nenhum convite encontrado para o seu e-mail ainda. Peça ao proprietário para convidar: ' + session.user.email);
  }

  const option = (value: 'points' | 'stamps', Icon: typeof Sparkles, title: string, text: string) => (
    <button type="button" onClick={() => setMode(value)}
      className={`rounded-2xl border p-4 text-left transition-colors cursor-pointer ${mode === value ? 'border-gold bg-surface-2' : 'border-line hover:bg-surface-2'}`}>
      <Icon size={20} className="text-gold" />
      <p className="mt-2 font-semibold">{title}</p>
      <p className="mt-0.5 text-xs text-muted">{text}</p>
    </button>
  );

  return (
    <div className="min-h-screen">
      <header className="flex items-center justify-between px-5 py-5"><Logo /><ThemeToggle /></header>
      <main className="mx-auto max-w-lg px-5 pb-16">
        <h1 className="text-3xl font-bold">Vamos configurar seu estabelecimento</h1>
        <p className="mt-2 text-muted">Leva 1 minuto. Você pode mudar tudo depois.</p>

        <form onSubmit={submit} className="card mt-6 space-y-5 p-6">
          <div>
            <label className="label" htmlFor="bn">Nome do estabelecimento</label>
            <input id="bn" className="input" required minLength={2} maxLength={80} value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex.: Barbearia Dom" />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="sg">Segmento</label>
              <select id="sg" className="input" value={segment} onChange={(e) => setSegment(e.target.value)}>
                {segments.map((s) => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="ph">WhatsApp <span className="text-muted">(opcional)</span></label>
              <input id="ph" className="input" inputMode="tel" value={phone} onChange={(e) => setPhone(maskPhone(e.target.value))} />
            </div>
          </div>
          <div>
            <p className="label">Como o cliente acumula?</p>
            <div className="grid gap-3 sm:grid-cols-2">
              {option('stamps', Stamp, 'Carimbos', '1 carimbo por visita. Ex.: 10 cortes = 1 grátis.')}
              {option('points', Sparkles, 'Pontos por valor', 'Ex.: cada R$ 10 gastos = 1 ponto.')}
            </div>
          </div>
          {mode === 'points' && (
            <div>
              <label className="label" htmlFor="am">Quantos reais valem 1 ponto?</label>
              <input id="am" className="input" inputMode="decimal" required value={amount} onChange={(e) => setAmount(e.target.value)} />
            </div>
          )}
          <Alert>{error}</Alert>
          <button className="btn btn-primary w-full" disabled={busy}>{busy && <Spinner />} Criar e começar teste de 30 dias</button>
        </form>

        <div className="mt-6 rounded-2xl border border-line p-5 text-sm text-muted">
          <p><strong className="text-fg">É funcionário?</strong> Peça ao proprietário para convidar o e-mail <strong className="text-fg">{session.user.email}</strong> em Configurações → Equipe.</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <button className="btn btn-ghost h-9" onClick={checkInvite} disabled={checking}>{checking && <Spinner />} Já fui convidado</button>
            <button className="btn btn-ghost h-9" onClick={() => signOut()}>Sair</button>
          </div>
        </div>
      </main>
    </div>
  );
}

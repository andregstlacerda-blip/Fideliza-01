import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CheckCircle2, Gift } from 'lucide-react';
import { supabase, errMsg } from '../../lib/supabase';
import { useSession } from '../../lib/session';
import { parseScan, unit } from '../../lib/format';
import Scanner from '../../components/Scanner';
import { Alert, PageHeader, Spinner } from '../../components/ui';

type Preview = { code: string; reward_name: string; cost: number; customer_name: string; status: string; balance: number };

const statusText: Record<string, string> = {
  confirmed: 'Este resgate já foi confirmado.',
  expired: 'Código expirado. Peça ao cliente para gerar um novo.',
  cancelled: 'O cliente cancelou este resgate.',
};

export default function Redeem() {
  const { program } = useSession();
  const [params, setParams] = useSearchParams();
  const [preview, setPreview] = useState<Preview | null>(null);
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState<{ reward: string; name: string; balance: number } | null>(null);

  const load = useCallback(async (c: string) => {
    setError(''); setDone(null);
    const { data, error } = await supabase.rpc('preview_redemption', { p_code: c });
    if (error) { setPreview(null); return setError(errMsg(error)); }
    setPreview(data as Preview);
  }, []);

  useEffect(() => {
    const c = params.get('codigo');
    if (c) { load(c); setParams({}, { replace: true }); }
  }, [params, setParams, load]);

  async function confirm() {
    if (!preview) return;
    setBusy(true); setError('');
    const { data, error } = await supabase.rpc('confirm_redemption', { p_code: preview.code });
    setBusy(false);
    if (error) return setError(errMsg(error));
    const r = data as { reward_name: string; customer_name: string; balance: number };
    setDone({ reward: r.reward_name, name: r.customer_name, balance: r.balance });
    setPreview(null);
  }

  function manual(e: FormEvent) {
    e.preventDefault();
    if (code.trim().length >= 6) load(code.trim());
  }

  if (!program) return null;
  const u = (n: number) => unit(program.mode, n);

  return (
    <>
      <PageHeader title="Confirmar resgate" subtitle="O cliente gera o QR de resgate na carteirinha dele" />
      {done && (
        <div className="card mb-4 flex items-center gap-3 p-5">
          <CheckCircle2 className="shrink-0 text-success" size={28} />
          <div>
            <p className="font-semibold">{done.reward} entregue para {done.name}</p>
            <p className="text-sm text-muted">Novo saldo: {done.balance} {u(done.balance)}</p>
          </div>
        </div>
      )}
      <div className="grid gap-6 lg:grid-cols-2">
        <div>
          <Scanner paused={!!preview} onScan={(t) => load(parseScan(t, 'codigo'))} />
          <form onSubmit={manual} className="mt-4 flex gap-2">
            <input className="input font-mono uppercase tracking-widest" placeholder="Código (8 letras)" maxLength={8}
              value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} />
            <button className="btn btn-ghost shrink-0">Buscar</button>
          </form>
        </div>
        <div>
          <Alert>{error}</Alert>
          {preview ? (
            <div className="card space-y-4 p-6">
              <div className="flex items-center gap-3">
                <span className="grid h-11 w-11 place-items-center rounded-full bg-surface-2 text-gold"><Gift size={20} /></span>
                <div>
                  <p className="font-semibold">{preview.reward_name}</p>
                  <p className="text-sm text-muted">{preview.customer_name} · custa {preview.cost} {u(preview.cost)} · saldo {preview.balance}</p>
                </div>
              </div>
              {preview.status !== 'pending'
                ? <Alert>{statusText[preview.status]}</Alert>
                : preview.balance < preview.cost
                  ? <Alert>Saldo insuficiente para este resgate.</Alert>
                  : null}
              <div className="flex gap-2">
                <button className="btn btn-ghost" onClick={() => setPreview(null)}>Voltar</button>
                <button className="btn btn-primary flex-1" onClick={confirm}
                  disabled={busy || preview.status !== 'pending' || preview.balance < preview.cost}>
                  {busy && <Spinner />} Confirmar e entregar
                </button>
              </div>
            </div>
          ) : (
            <div className="card p-6 text-sm text-muted">
              Escaneie o QR de resgate que aparece na carteirinha do cliente. Os {u(2)} só são descontados quando você confirmar.
            </div>
          )}
        </div>
      </div>
    </>
  );
}

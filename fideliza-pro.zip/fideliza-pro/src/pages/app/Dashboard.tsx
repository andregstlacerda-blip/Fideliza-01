import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Award, Check, Gift, PlusCircle, QrCode, Users } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useSession } from '../../lib/session';
import { unit } from '../../lib/format';
import { PageHeader, PageLoader, Stat } from '../../components/ui';

type Stats = {
  customers: number; customers_30d: number; points_issued_30d: number; redemptions_30d: number;
  active_customers_30d: number; top_customers: { id: string; name: string; balance: number }[];
};

export default function Dashboard() {
  const { business, program, role } = useSession();
  const [stats, setStats] = useState<Stats | null>(null);
  const [rewardCount, setRewardCount] = useState(0);

  useEffect(() => {
    if (!business) return;
    supabase.rpc('dashboard_stats', { p_business: business.id }).then(({ data }) => setStats(data as Stats));
    supabase.from('rewards').select('id', { count: 'exact', head: true }).eq('business_id', business.id)
      .then(({ count }) => setRewardCount(count || 0));
  }, [business]);

  if (!stats || !program) return <PageLoader />;
  const u = (n: number) => unit(program.mode, n);
  const setup = [
    { done: true, text: 'Estabelecimento criado' },
    { done: rewardCount > 0, text: 'Cadastrar a primeira recompensa', to: '/app/recompensas' },
    { done: stats.customers > 0, text: 'Imprimir o QR do balcão e cadastrar o primeiro cliente', to: '/app/qr' },
  ];
  const showSetup = role === 'owner' && setup.some((s) => !s.done);

  return (
    <>
      <PageHeader title={`Olá, ${business?.name}`} subtitle="Resumo dos últimos 30 dias" />

      {showSetup && (
        <div className="card mb-6 p-5">
          <h2 className="font-bold">Primeiros passos</h2>
          <ul className="mt-3 space-y-2">
            {setup.map((s) => (
              <li key={s.text} className="flex items-center gap-3 text-sm">
                <span className={`grid h-6 w-6 shrink-0 place-items-center rounded-full ${s.done ? 'bg-primary text-primary-fg' : 'border border-line'}`}>{s.done && <Check size={14} />}</span>
                {s.to && !s.done ? <Link to={s.to} className="font-medium text-gold hover:underline">{s.text}</Link> : <span className={s.done ? 'text-muted line-through' : ''}>{s.text}</span>}
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Clientes" value={stats.customers} hint={`+${stats.customers_30d} no período`} />
        <Stat label="Clientes ativos" value={stats.active_customers_30d} hint="Compraram no período" />
        <Stat label={`${u(2)[0].toUpperCase()}${u(2).slice(1)} emitidos`} value={stats.points_issued_30d} />
        <Stat label="Resgates" value={stats.redemptions_30d} />
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-3">
        <Link to="/app/pontuar" className="card flex items-center gap-3 p-5 hover:bg-surface-2"><PlusCircle className="text-gold" /> <span className="font-semibold">Pontuar cliente</span></Link>
        <Link to="/app/resgatar" className="card flex items-center gap-3 p-5 hover:bg-surface-2"><Gift className="text-gold" /> <span className="font-semibold">Confirmar resgate</span></Link>
        <Link to="/app/qr" className="card flex items-center gap-3 p-5 hover:bg-surface-2"><QrCode className="text-gold" /> <span className="font-semibold">QR do balcão</span></Link>
      </div>

      <div className="card mt-6 p-5">
        <h2 className="flex items-center gap-2 font-bold"><Award size={18} className="text-gold" /> Clientes com mais {u(2)}</h2>
        {stats.top_customers.length === 0 ? (
          <p className="mt-3 flex items-center gap-2 text-sm text-muted"><Users size={16} /> Nenhum cliente ainda.</p>
        ) : (
          <ul className="mt-3 divide-y divide-line">
            {stats.top_customers.map((c) => (
              <li key={c.id}>
                <Link to={`/app/clientes/${c.id}`} className="flex justify-between py-2.5 text-sm hover:text-gold">
                  <span>{c.name}</span><span className="font-semibold">{c.balance} {u(c.balance)}</span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  );
}

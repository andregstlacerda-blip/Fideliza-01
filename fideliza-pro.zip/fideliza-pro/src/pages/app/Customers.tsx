import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { QrCode, Search, Users } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useSession } from '../../lib/session';
import { dateBR, formatPhone, unit } from '../../lib/format';
import { Empty, PageHeader, PageLoader } from '../../components/ui';

type Row = { id: string; name: string; phone: string; balance: number; last_visit: string | null; created_at: string };

export default function Customers() {
  const { business, program, license } = useSession();
  const [rows, setRows] = useState<Row[] | null>(null);
  const [q, setQ] = useState('');

  useEffect(() => {
    if (!business) return;
    const t = setTimeout(() => {
      supabase.rpc('customers_with_balance', { p_business: business.id, p_search: q.trim() || null })
        .then(({ data }) => setRows((data as Row[]) || []));
    }, 250);
    return () => clearTimeout(t);
  }, [business, q]);

  if (!rows || !program) return <PageLoader />;
  const u = (n: number) => unit(program.mode, n);

  return (
    <>
      <PageHeader title="Clientes" subtitle={`Limite da licença: ${license?.max_customers ?? 500} clientes`} />
      <div className="relative mb-4">
        <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
        <input className="input pl-10" placeholder="Buscar por nome ou telefone" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      {rows.length === 0 ? (
        <Empty icon={<Users size={22} />} title={q ? 'Nenhum resultado' : 'Nenhum cliente ainda'}
          text={q ? 'Tente outro nome ou telefone.' : 'Os clientes entram escaneando o QR do balcão. Imprima e deixe à vista.'}
          action={!q && <Link to="/app/qr" className="btn btn-primary"><QrCode size={18} /> Ver QR do balcão</Link>} />
      ) : (
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="border-b border-line text-left text-muted">
              <tr><th className="px-4 py-3 font-medium">Cliente</th><th className="hidden px-4 py-3 font-medium sm:table-cell">Última compra</th><th className="px-4 py-3 text-right font-medium">Saldo</th></tr>
            </thead>
            <tbody className="divide-y divide-line">
              {rows.map((r) => (
                <tr key={r.id} className="hover:bg-surface-2">
                  <td className="px-4 py-3">
                    <Link to={`/app/clientes/${r.id}`} className="block">
                      <span className="font-medium">{r.name}</span>
                      <span className="block text-xs text-muted">{formatPhone(r.phone)}</span>
                    </Link>
                  </td>
                  <td className="hidden px-4 py-3 text-muted sm:table-cell">{dateBR(r.last_visit)}</td>
                  <td className="px-4 py-3 text-right font-semibold">{r.balance} <span className="font-normal text-muted">{u(r.balance)}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}

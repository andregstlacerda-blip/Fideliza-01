import { QRCodeSVG } from 'qrcode.react';
import { Copy, Printer } from 'lucide-react';
import { useState } from 'react';
import { useSession } from '../../lib/session';
import { brl, origin, unit } from '../../lib/format';
import { PageHeader } from '../../components/ui';

export default function CounterQR() {
  const { business, program } = useSession();
  const [copied, setCopied] = useState(false);
  if (!business || !program) return null;
  const url = `${origin()}/e/${business.join_code}`;
  const rule = program.mode === 'points'
    ? `1 ponto a cada ${brl(Number(program.amount_per_point))}`
    : `${program.stamps_per_visit} ${unit('stamps', program.stamps_per_visit)} por visita`;

  return (
    <>
      <style>{`@media print { body * { visibility: hidden; } #poster, #poster * { visibility: visible; } #poster { position: absolute; inset: 0; margin: auto; } }`}</style>
      <div className="print:hidden">
        <PageHeader title="QR do balcão" subtitle="Imprima e deixe à vista. É por aqui que os clientes entram no programa."
          action={<div className="flex gap-2">
            <button className="btn btn-ghost" onClick={() => { navigator.clipboard?.writeText(url); setCopied(true); }}><Copy size={18} /> {copied ? 'Copiado' : 'Copiar link'}</button>
            <button className="btn btn-primary" onClick={() => window.print()}><Printer size={18} /> Imprimir</button>
          </div>} />
      </div>

      <div id="poster" className="mx-auto w-full max-w-sm rounded-[28px] bg-[#0E0E10] p-8 text-center text-[#F5F2EC] ring-1 ring-[#C9A050]/30">
        <p className="text-xs uppercase tracking-[0.25em] text-[#C9A050]">Programa de fidelidade</p>
        <h2 className="mt-2 text-2xl font-extrabold">{business.name}</h2>
        <p className="mt-2 text-sm text-[#A29C90]">Aponte a câmera, crie sua carteirinha e ganhe {rule}.</p>
        <div className="mx-auto mt-6 w-fit rounded-2xl bg-white p-4">
          <QRCodeSVG value={url} size={220} fgColor="#0E0E10" level="M" />
        </div>
        <p className="mt-6 font-display text-lg font-bold text-[#E8D5A8]">Junte e ganhe recompensas</p>
        <p className="mt-4 text-[10px] text-[#A29C90]">Fideliza Pro</p>
      </div>
    </>
  );
}

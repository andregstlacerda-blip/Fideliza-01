import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Sparkles, Stamp, UserPlus, Trash2 } from 'lucide-react';
import { supabase, errMsg } from '../../lib/supabase';
import { useSession } from '../../lib/session';
import { dateBR, maskPhone } from '../../lib/format';
import { Alert, PageHeader, Spinner } from '../../components/ui';

type Invite = { id: string; email: string; accepted_at: string | null };
const statusLabel: Record<string, string> = { trial: 'Período de teste', active: 'Ativa', expired: 'Expirada', blocked: 'Bloqueada' };

export default function Settings() {
  const { business, program, license, refresh } = useSession();

  // Estabelecimento
  const [bName, setBName] = useState(business?.name || '');
  const [bPhone, setBPhone] = useState(maskPhone(business?.phone || ''));
  // Programa
  const [mode, setMode] = useState(program?.mode || 'stamps');
  const [amount, setAmount] = useState(String(program?.amount_per_point ?? 10).replace('.', ','));
  const [stamps, setStamps] = useState(String(program?.stamps_per_visit ?? 1));
  const [welcome, setWelcome] = useState(program?.welcome_message || '');
  const [active, setActive] = useState(program?.active ?? true);
  // Equipe
  const [invites, setInvites] = useState<Invite[]>([]);
  const [email, setEmail] = useState('');

  const [busy, setBusy] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ k: string; text: string; ok: boolean } | null>(null);

  const loadInvites = useCallback(async () => {
    if (!business) return;
    const { data } = await supabase.from('staff_invites').select('id, email, accepted_at').eq('business_id', business.id).order('created_at');
    setInvites((data as Invite[]) || []);
  }, [business]);
  useEffect(() => { loadInvites(); }, [loadInvites]);

  if (!business || !program) return null;

  const run = async (k: string, fn: () => PromiseLike<{ error: unknown }>, ok: string) => {
    setBusy(k); setMsg(null);
    const { error } = await fn();
    setBusy(null);
    setMsg(error ? { k, text: errMsg(error), ok: false } : { k, text: ok, ok: true });
    return !error;
  };
  const note = (k: string) => msg?.k === k && <Alert kind={msg.ok ? 'success' : 'error'}>{msg.text}</Alert>;

  async function saveBusiness(e: FormEvent) {
    e.preventDefault();
    if (await run('b', () => supabase.from('businesses').update({ name: bName.trim(), phone: bPhone.replace(/\D/g, '') || null }).eq('id', business!.id), 'Dados salvos.')) refresh();
  }

  async function saveProgram(e: FormEvent) {
    e.preventDefault();
    const changed = mode !== program!.mode;
    if (changed && !window.confirm('Mudar o tipo do programa não converte os saldos atuais dos clientes. Revise também o custo das recompensas. Continuar?')) return;
    if (await run('p', () => supabase.from('loyalty_programs').update({
      mode, amount_per_point: Number(amount.replace(',', '.')) || 10,
      stamps_per_visit: Math.min(10, Math.max(1, parseInt(stamps, 10) || 1)),
      welcome_message: welcome.trim() || null, active, updated_at: new Date().toISOString(),
    }).eq('business_id', business!.id), 'Programa atualizado.')) refresh();
  }

  async function invite(e: FormEvent) {
    e.preventDefault();
    if (await run('t', () => supabase.rpc('invite_staff', { p_business: business!.id, p_email: email }),
      'Convite criado. Peça ao funcionário para criar a conta com este e-mail.')) { setEmail(''); loadInvites(); }
  }

  async function remove(i: Invite) {
    if (!window.confirm(`Remover ${i.email} da equipe?`)) return;
    if (await run('t', () => supabase.rpc('remove_staff', { p_invite: i.id }), 'Acesso removido.')) loadInvites();
  }

  const modeBtn = (v: 'points' | 'stamps', Icon: typeof Stamp, label: string) => (
    <button type="button" onClick={() => setMode(v)}
      className={`flex items-center gap-2 rounded-xl border px-4 h-11 text-sm font-medium cursor-pointer ${mode === v ? 'border-gold bg-surface-2' : 'border-line'}`}>
      <Icon size={16} className="text-gold" /> {label}
    </button>
  );

  return (
    <>
      <PageHeader title="Configurações" />
      <div className="grid gap-6 lg:grid-cols-2">
        <form onSubmit={saveProgram} className="card space-y-4 p-6">
          <h2 className="font-bold">Programa de fidelidade</h2>
          <div className="flex flex-wrap gap-2">
            {modeBtn('stamps', Stamp, 'Carimbos por visita')}
            {modeBtn('points', Sparkles, 'Pontos por valor')}
          </div>
          {mode === 'points' ? (
            <div>
              <label className="label" htmlFor="am">Reais para 1 ponto</label>
              <input id="am" className="input" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} />
            </div>
          ) : (
            <div>
              <label className="label" htmlFor="st">Carimbos por visita</label>
              <input id="st" className="input" inputMode="numeric" value={stamps} onChange={(e) => setStamps(e.target.value.replace(/\D/g, ''))} />
            </div>
          )}
          <div>
            <label className="label" htmlFor="wm">Mensagem de boas-vindas <span className="text-muted">(opcional)</span></label>
            <input id="wm" className="input" maxLength={140} placeholder="Ex.: A cada 10 cortes, o próximo é por nossa conta!" value={welcome} onChange={(e) => setWelcome(e.target.value)} />
          </div>
          <label className="flex items-center gap-3 text-sm">
            <input type="checkbox" className="h-4 w-4 accent-[#A8843F]" checked={active} onChange={(e) => setActive(e.target.checked)} />
            Programa ativo (desmarque para pausar a pontuação)
          </label>
          {note('p')}
          <button className="btn btn-primary w-full" disabled={busy === 'p'}>{busy === 'p' && <Spinner />} Salvar programa</button>
        </form>

        <div className="space-y-6">
          <form onSubmit={saveBusiness} className="card space-y-4 p-6">
            <h2 className="font-bold">Estabelecimento</h2>
            <div>
              <label className="label" htmlFor="bn">Nome</label>
              <input id="bn" className="input" required minLength={2} value={bName} onChange={(e) => setBName(e.target.value)} />
            </div>
            <div>
              <label className="label" htmlFor="bp">WhatsApp</label>
              <input id="bp" className="input" inputMode="tel" value={bPhone} onChange={(e) => setBPhone(maskPhone(e.target.value))} />
            </div>
            {note('b')}
            <button className="btn btn-ghost w-full" disabled={busy === 'b'}>{busy === 'b' && <Spinner />} Salvar dados</button>
          </form>

          <div className="card space-y-4 p-6">
            <h2 className="font-bold">Equipe <span className="text-sm font-normal text-muted">· até {license?.max_staff ?? 2} funcionários</span></h2>
            {invites.length > 0 && (
              <ul className="divide-y divide-line text-sm">
                {invites.map((i) => (
                  <li key={i.id} className="flex items-center justify-between gap-2 py-2.5">
                    <span className="min-w-0 truncate">{i.email} <span className="text-muted">· {i.accepted_at ? 'ativo' : 'aguardando cadastro'}</span></span>
                    <button className="shrink-0 text-muted hover:text-danger cursor-pointer" onClick={() => remove(i)} aria-label="Remover"><Trash2 size={16} /></button>
                  </li>
                ))}
              </ul>
            )}
            <form onSubmit={invite} className="flex gap-2">
              <input type="email" className="input" placeholder="email@funcionario.com" required value={email} onChange={(e) => setEmail(e.target.value)} />
              <button className="btn btn-ghost shrink-0" disabled={busy === 't'} aria-label="Convidar">{busy === 't' ? <Spinner /> : <UserPlus size={18} />}</button>
            </form>
            {note('t')}
          </div>

          <div className="card p-6 text-sm">
            <h2 className="font-bold">Licença</h2>
            <p className="mt-2 text-muted">Situação: <strong className="text-fg">{statusLabel[license?.status || ''] || license?.status}</strong>
              {license?.expires_at && <> · até {dateBR(license.expires_at)}</>}</p>
            <p className="mt-1 text-muted">Limites: 1 estabelecimento · {license?.max_customers} clientes · {license?.max_staff} funcionários</p>
          </div>
        </div>
      </div>
    </>
  );
}

import { useCallback, useEffect, useRef, useState } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { Check, Gift, PartyPopper, X } from 'lucide-react';
import { supabase, errMsg } from '../../lib/supabase';
import { brl, dateTimeBR, origin, unit } from '../../lib/format';
import { Alert, Logo, PageLoader, Spinner, ThemeToggle } from '../../components/ui';

type Reward = { id: string; name: string; description: string | null; cost: number };
type Pending = { code: string; reward_name: string; cost: number; expires_at: string } | null;
type CardData = {
  customer_name: string; business_name: string; mode: 'points' | 'stamps'; amount_per_point: number;
  stamps_per_visit: number; balance: number; rewards: Reward[]; pending: Pending;
  history: { kind: string; points: number; created_at: string }[];
};

function Countdown({ until, onEnd }: { until: string; onEnd: () => void }) {
  const [left, setLeft] = useState(() => new Date(until).getTime() - Date.now());
  useEffect(() => {
    const t = setInterval(() => {
      const l = new Date(until).getTime() - Date.now();
      setLeft(l);
      if (l <= 0) { clearInterval(t); onEnd(); }
    }, 1000);
    return () => clearInterval(t);
  }, [until, onEnd]);
  const s = Math.max(0, Math.floor(left / 1000));
  return <>{String(Math.floor(s / 60)).padStart(2, '0')}:{String(s % 60).padStart(2, '0')}</>;
}

export default function Card() {
  const { token = '' } = useParams();
  const [params] = useSearchParams();
  const [data, setData] = useState<CardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [celebrate, setCelebrate] = useState<string | null>(null);
  const pendingRef = useRef<Pending>(null);
  const balanceRef = useRef<number | null>(null);

  const load = useCallback(async () => {
    const { data } = await supabase.rpc('get_card', { p_token: token });
    const d = data as CardData | null;
    // resgate pendente sumiu e o saldo caiu → foi confirmado no balcão
    if (pendingRef.current && d && !d.pending && balanceRef.current !== null && d.balance < balanceRef.current) {
      setCelebrate(pendingRef.current.reward_name);
    }
    pendingRef.current = d?.pending ?? null;
    balanceRef.current = d?.balance ?? null;
    setData(d);
    setLoading(false);
  }, [token]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const onFocus = () => load();
    window.addEventListener('focus', onFocus);
    // enquanto houver resgate pendente, atualiza a cada 4s para mostrar a confirmação
    const t = data?.pending ? setInterval(load, 4000) : null;
    return () => { window.removeEventListener('focus', onFocus); if (t) clearInterval(t); };
  }, [load, data?.pending]);

  async function redeem(r: Reward) {
    setBusy(r.id); setError(''); setCelebrate(null);
    const { error } = await supabase.rpc('request_redemption', { p_token: token, p_reward: r.id });
    setBusy(null);
    if (error) return setError(errMsg(error));
    await load();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function cancel() {
    setBusy('cancel');
    await supabase.rpc('cancel_redemption', { p_token: token });
    pendingRef.current = null;
    setBusy(null);
    load();
  }

  if (loading) return <PageLoader />;
  if (!data) {
    return <div className="grid min-h-screen place-items-center p-6 text-center"><div><Logo /><p className="mt-6 text-muted">Carteirinha não encontrada.</p></div></div>;
  }

  const u = (n: number) => unit(data.mode, n);
  const next = data.rewards.find((r) => r.cost > data.balance);
  const goal = next?.cost ?? data.rewards[data.rewards.length - 1]?.cost ?? 10;
  const showStamps = data.mode === 'stamps' && goal <= 20;

  return (
    <div className="min-h-screen">
      <header className="flex items-center justify-between px-5 py-4"><Logo size="sm" /><ThemeToggle /></header>
      <main className="mx-auto max-w-md space-y-4 px-5 pb-12">
        {params.get('novo') && !data.pending && (
          <Alert kind="success">Carteirinha criada! Salve este link ou adicione à tela inicial para abrir sempre que vier.</Alert>
        )}
        {celebrate && (
          <div className="card flex items-center gap-3 p-4">
            <PartyPopper className="text-gold" />
            <p className="text-sm"><strong>{celebrate}</strong> resgatado. Aproveite!</p>
          </div>
        )}

        {data.pending ? (
          <section className="rounded-3xl bg-[#0E0E10] p-6 text-center text-[#F5F2EC] ring-1 ring-[#C9A050]/40">
            <p className="text-xs uppercase tracking-[0.2em] text-[#C9A050]">Resgate</p>
            <h1 className="mt-1 text-xl font-bold">{data.pending.reward_name}</h1>
            <p className="mt-1 text-sm text-[#A29C90]">Mostre este QR para a equipe confirmar</p>
            <div className="mx-auto mt-5 w-fit rounded-2xl bg-white p-4">
              <QRCodeSVG value={`${origin()}/app/resgatar?codigo=${data.pending.code}`} size={208} fgColor="#0E0E10" />
            </div>
            <p className="mt-4 font-mono text-2xl tracking-[0.3em] text-[#E8D5A8]">{data.pending.code}</p>
            <p className="mt-2 text-sm text-[#A29C90]">Expira em <Countdown until={data.pending.expires_at} onEnd={load} /></p>
            <button className="mt-5 inline-flex items-center gap-1.5 text-sm text-[#A29C90] hover:text-[#F5F2EC] cursor-pointer" onClick={cancel} disabled={busy === 'cancel'}>
              <X size={16} /> Cancelar resgate
            </button>
          </section>
        ) : (
          <section className="rounded-3xl bg-[#0E0E10] p-6 text-[#F5F2EC] ring-1 ring-[#C9A050]/25">
            <p className="text-xs uppercase tracking-[0.2em] text-[#C9A050]">{data.business_name}</p>
            <h1 className="mt-1 text-xl font-bold">Olá, {data.customer_name}</h1>

            {showStamps ? (
              <div className="mt-5 grid grid-cols-5 gap-2">
                {Array.from({ length: goal }).map((_, i) => (
                  <div key={i} className={`grid aspect-square place-items-center rounded-full border ${i < data.balance ? 'border-[#C9A050] bg-[#C9A050] text-[#0E0E10]' : 'border-[#2C2C31] text-[#2C2C31]'}`}>
                    <Check size={16} strokeWidth={3} />
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-4 font-display text-5xl font-extrabold text-[#E8D5A8]">{data.balance}<span className="ml-2 text-base font-semibold text-[#A29C90]">{u(data.balance)}</span></p>
            )}
            <p className="mt-3 text-sm text-[#A29C90]">
              {next ? <>Faltam <span className="text-[#E8D5A8]">{next.cost - data.balance} {u(next.cost - data.balance)}</span> para {next.name}</>
                : data.rewards.length ? 'Você já pode resgatar recompensas!' : 'Acumule e troque por recompensas.'}
            </p>

            <div className="mt-6 rounded-2xl bg-[#1A1A1D] p-5 text-center">
              <div className="mx-auto w-fit rounded-xl bg-white p-3">
                <QRCodeSVG value={`${origin()}/app/pontuar?cartao=${token}`} size={168} fgColor="#0E0E10" />
              </div>
              <p className="mt-3 text-sm text-[#E8D5A8]">Mostre no balcão para ganhar {u(2)}</p>
              <p className="mt-1 text-xs text-[#A29C90]">
                {data.mode === 'points' ? `1 ponto a cada ${brl(Number(data.amount_per_point))}` : `${data.stamps_per_visit} ${u(data.stamps_per_visit)} por visita`}
              </p>
            </div>
          </section>
        )}

        <Alert>{error}</Alert>

        {data.rewards.length > 0 && (
          <section className="card p-5">
            <h2 className="font-bold">Recompensas</h2>
            <ul className="mt-3 divide-y divide-line">
              {data.rewards.map((r) => {
                const can = data.balance >= r.cost;
                return (
                  <li key={r.id} className="flex items-center justify-between gap-3 py-3">
                    <div className="min-w-0">
                      <p className="flex items-center gap-2 font-medium"><Gift size={16} className="shrink-0 text-gold" /> {r.name}</p>
                      <p className="text-sm text-muted">{r.cost} {u(r.cost)}{r.description ? ` · ${r.description}` : ''}</p>
                    </div>
                    <button className={`btn h-9 shrink-0 ${can ? 'btn-primary' : 'btn-ghost'}`} disabled={!can || !!busy || !!data.pending} onClick={() => redeem(r)}>
                      {busy === r.id ? <Spinner /> : 'Resgatar'}
                    </button>
                  </li>
                );
              })}
            </ul>
          </section>
        )}

        {data.history.length > 0 && (
          <section className="card p-5">
            <h2 className="font-bold">Histórico</h2>
            <ul className="mt-3 space-y-2 text-sm">
              {data.history.map((h, i) => (
                <li key={i} className="flex justify-between">
                  <span className="text-muted">{h.kind === 'earn' ? 'Compra' : h.kind === 'redeem' ? 'Resgate' : 'Ajuste'} · {dateTimeBR(h.created_at)}</span>
                  <span className={h.points > 0 ? 'text-success' : 'text-danger'}>{h.points > 0 ? '+' : ''}{h.points}</span>
                </li>
              ))}
            </ul>
          </section>
        )}
      </main>
    </div>
  );
}

import { useState, type FormEvent } from 'react';
import { Link, Navigate, useSearchParams } from 'react-router-dom';
import { supabase, errMsg } from '../../lib/supabase';
import { useSession } from '../../lib/session';
import { Alert, Logo, Spinner, ThemeToggle } from '../../components/ui';

export default function Auth({ mode }: { mode: 'login' | 'signup' }) {
  const { session, loading } = useSession();
  const [params] = useSearchParams();
  const back = params.get('voltar') || '/app';
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  if (!loading && session) return <Navigate to={back.startsWith('/') ? back : '/app'} replace />;

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setError(''); setInfo('');
    try {
      if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
      } else {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(), password,
          options: { data: { full_name: name.trim() }, emailRedirectTo: `${window.location.origin}/app` },
        });
        if (error) throw error;
        if (!data.session) setInfo('Conta criada! Enviamos um link de confirmação para o seu e-mail. Confirme e depois faça login.');
      }
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  }

  const isLogin = mode === 'login';
  return (
    <div className="flex min-h-screen flex-col">
      <header className="flex items-center justify-between px-5 py-5">
        <Link to="/"><Logo /></Link>
        <ThemeToggle />
      </header>
      <main className="grid flex-1 place-items-center px-5 pb-16">
        <form onSubmit={submit} className="card w-full max-w-sm p-6 sm:p-8">
          <h1 className="text-2xl font-bold">{isLogin ? 'Entrar' : 'Criar conta'}</h1>
          <p className="mt-1 text-sm text-muted">
            {isLogin ? 'Acesse o painel do seu estabelecimento.' : 'Dono ou funcionário convidado: crie sua conta com seu e-mail.'}
          </p>
          <div className="mt-6 space-y-4">
            {!isLogin && (
              <div>
                <label className="label" htmlFor="name">Seu nome</label>
                <input id="name" className="input" required minLength={2} value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
              </div>
            )}
            <div>
              <label className="label" htmlFor="email">E-mail</label>
              <input id="email" type="email" className="input" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
            </div>
            <div>
              <label className="label" htmlFor="password">Senha</label>
              <input id="password" type="password" className="input" required minLength={6} value={password}
                onChange={(e) => setPassword(e.target.value)} autoComplete={isLogin ? 'current-password' : 'new-password'} />
            </div>
            <Alert>{error}</Alert>
            <Alert kind="success">{info}</Alert>
            <button className="btn btn-primary w-full" disabled={busy}>{busy && <Spinner />} {isLogin ? 'Entrar' : 'Criar conta'}</button>
          </div>
          <p className="mt-6 text-center text-sm text-muted">
            {isLogin ? <>Ainda não tem conta? <Link className="font-semibold text-gold" to="/cadastro">Criar conta</Link></>
              : <>Já tem conta? <Link className="font-semibold text-gold" to="/entrar">Entrar</Link></>}
          </p>
        </form>
      </main>
    </div>
  );
}

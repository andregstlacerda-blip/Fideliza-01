import { Link } from 'react-router-dom';
import { QrCode, Sparkles, Gift, ShieldCheck, Smartphone, BarChart3, Check } from 'lucide-react';
import { Logo, ThemeToggle } from '../../components/ui';
import { useSession } from '../../lib/session';

const steps = [
  { icon: QrCode, title: 'Cliente entra pelo QR', text: 'Você imprime o QR do balcão. O cliente escaneia, se cadastra em segundos e recebe a carteirinha no celular.' },
  { icon: Sparkles, title: 'Pontos ou carimbos', text: 'A cada compra, sua equipe escaneia a carteirinha. Você escolhe: pontos por valor gasto ou carimbos por visita.' },
  { icon: Gift, title: 'Resgate com QR', text: 'O cliente escolhe a recompensa e mostra o QR de resgate. A equipe escaneia e confirma. Sem fraude, sem papel.' },
];

const features = [
  { icon: Smartphone, title: 'Sem aplicativo para baixar', text: 'Tudo funciona no navegador do celular, para você e para o cliente.' },
  { icon: ShieldCheck, title: 'Seguro de verdade', text: 'Cada operação é validada no servidor. Pontos não duplicam e o saldo nunca fica negativo.' },
  { icon: BarChart3, title: 'Painel simples', text: 'Clientes ativos, pontos emitidos, resgates e quem mais volta.' },
];

export default function Landing() {
  const { session } = useSession();
  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
        <Logo />
        <div className="flex items-center gap-2">
          <ThemeToggle />
          {session
            ? <Link to="/app" className="btn btn-primary">Abrir painel</Link>
            : <Link to="/entrar" className="btn btn-ghost">Entrar</Link>}
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-5 pb-16 pt-10 sm:pt-20">
        <div className="grid items-center gap-12 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <span className="chip border border-line bg-surface text-gold">Fidelidade digital para pequenos negócios</span>
            <h1 className="mt-5 text-4xl font-extrabold leading-[1.05] sm:text-6xl">
              Seu cliente volta. <span className="text-gold">Sempre.</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-muted">
              Troque o cartão de papel por uma carteirinha digital com QR Code. Feito para barbearias, cafeterias,
              docerias, restaurantes e lojas de bairro.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/cadastro" className="btn btn-primary h-12 px-6 text-base">Testar grátis por 30 dias</Link>
              <a href="#como-funciona" className="btn btn-ghost h-12 px-6 text-base">Como funciona</a>
            </div>
          </div>

          {/* Mock da carteirinha */}
          <div className="mx-auto w-full max-w-sm">
            <div className="rounded-[28px] bg-[#0E0E10] p-6 text-[#F5F2EC] shadow-2xl ring-1 ring-[#C9A050]/25">
              <p className="text-xs uppercase tracking-[0.2em] text-[#C9A050]">Barbearia Dom</p>
              <p className="mt-1 font-display text-xl font-bold">Olá, Rafael</p>
              <div className="mt-6 grid grid-cols-5 gap-2">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div key={i} className={`grid aspect-square place-items-center rounded-full border ${i < 7 ? 'border-[#C9A050] bg-[#C9A050] text-[#0E0E10]' : 'border-[#2C2C31] text-[#2C2C31]'}`}>
                    <Check size={16} strokeWidth={3} />
                  </div>
                ))}
              </div>
              <p className="mt-4 text-sm text-[#A29C90]">Faltam <span className="text-[#E8D5A8]">3 cortes</span> para o próximo grátis</p>
              <div className="mt-6 rounded-2xl bg-[#1A1A1D] p-4 text-center text-sm text-[#E8D5A8]">Mostre este QR no balcão</div>
            </div>
          </div>
        </div>
      </section>

      <section id="como-funciona" className="border-y border-line bg-surface">
        <div className="mx-auto max-w-6xl px-5 py-16">
          <h2 className="text-3xl font-bold">Como funciona</h2>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {steps.map((s, i) => (
              <div key={s.title} className="rounded-2xl border border-line bg-bg p-6">
                <div className="flex items-center gap-3">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-surface-2 text-gold"><s.icon size={20} /></span>
                  <span className="text-sm text-muted">Passo {i + 1}</span>
                </div>
                <h3 className="mt-4 text-lg font-bold">{s.title}</h3>
                <p className="mt-2 text-sm text-muted">{s.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-16">
        <div className="grid gap-4 md:grid-cols-3">
          {features.map((f) => (
            <div key={f.title} className="card p-6">
              <f.icon className="text-gold" size={22} />
              <h3 className="mt-3 font-bold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-20">
        <div className="mx-auto max-w-md rounded-3xl border border-line bg-surface p-8 text-center">
          <p className="text-sm font-medium text-gold">Pagamento único</p>
          <p className="mt-2 font-display text-5xl font-extrabold">R$ 97</p>
          <ul className="mt-6 space-y-2 text-left text-sm">
            {['1 estabelecimento', 'Até 500 clientes', 'Até 2 funcionários', '1 programa de fidelidade (pontos ou carimbos)', 'Carteirinha digital e QR de resgate'].map((t) => (
              <li key={t} className="flex items-center gap-2"><Check size={16} className="text-gold" /> {t}</li>
            ))}
          </ul>
          <Link to="/cadastro" className="btn btn-primary mt-8 w-full">Começar teste grátis</Link>
          <p className="mt-3 text-xs text-muted">As condições de hospedagem, suporte e atualizações incluídas são informadas antes da compra.</p>
        </div>
      </section>

      <footer className="border-t border-line py-8 text-center text-sm text-muted">
        © {new Date().getFullYear()} Fideliza Pro
      </footer>
    </div>
  );
}

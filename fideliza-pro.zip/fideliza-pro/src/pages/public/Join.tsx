import { useEffect, useState, type FormEvent } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Gift } from 'lucide-react';
import { supabase, errMsg } from '../../lib/supabase';
import { brl, maskPhone, unit } from '../../lib/format';
import { saveCard, savedCard } from '../../lib/cards';
import { Alert, Logo, PageLoader, Spinner, ThemeToggle } from '../../components/ui';

type Info = {
  business_name: string; mode: 'points' | 'stamps'; amount_per_point: number; stamps_per_visit: number;
  welcome_message: string | null; rewards: { name: string; cost: number }[];
};

export default function Join() {
  const { code = '' } = useParams();
  const nav = useNavigate();
  const [info, setInfo] = useState<Info | null>(null);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [birthday, setBirthday] = useState('');
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const existing = savedCard(code);

  useEffect(() => {
    supabase.rpc('get_join_info', { p_join_code: code }).then(({ data }) => {
      setInfo(data as Info);
      setLoading(false);
    });
  }, [code]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setError('');
    const { data, error } = await supabase.rpc('join_business', {
      p_join_code: code, p_name: name, p_phone: phone, p_email: email || null,
      p_birthday: birthday || null, p_consent: consent,
    });
    setBusy(false);
    if (error) return setError(errMsg(error));
    saveCard(code, data as string);
    nav(`/c/${data}?novo=1`, { replace: true });
  }

  if (loading) return <PageLoader />;
  if (!info) {
    return (
      <div className="grid min-h-screen place-items-center p-6 text-center">
        <div><Logo /><p className="mt-6 text-muted">Este QR Code não é válido. Peça um novo no estabelecimento.</p></div>
      </div>
    );
  }

  const rule = info.mode === 'points'
    ? `Ganhe 1 ponto a cada ${brl(Number(info.amount_per_point))} em compras.`
    : `Ganhe ${info.stamps_per_visit} ${unit('stamps', info.stamps_per_visit)} a cada visita.`;

  return (
    <div className="min-h-screen">
      <header className="flex items-center justify-between px-5 py-4"><Logo size="sm" /><ThemeToggle /></header>
      <main className="mx-auto max-w-md px-5 pb-12">
        <div className="rounded-3xl bg-[#0E0E10] p-6 text-[#F5F2EC] ring-1 ring-[#C9A050]/25">
          <p className="text-xs uppercase tracking-[0.2em] text-[#C9A050]">Programa de fidelidade</p>
          <h1 className="mt-1 text-2xl font-bold">{info.business_name}</h1>
          <p className="mt-2 text-sm text-[#A29C90]">{info.welcome_message || rule}</p>
          {info.welcome_message && <p className="mt-1 text-sm text-[#E8D5A8]">{rule}</p>}
          {info.rewards.length > 0 && (
            <ul className="mt-4 space-y-1.5 text-sm">
              {info.rewards.slice(0, 4).map((r) => (
                <li key={r.name} className="flex items-center gap-2"><Gift size={14} className="text-[#C9A050]" /> {r.name} · {r.cost} {unit(info.mode, r.cost)}</li>
              ))}
            </ul>
          )}
        </div>

        {existing && (
          <Link to={`/c/${existing}`} className="btn btn-primary mt-4 w-full">Você já participa · abrir minha carteirinha</Link>
        )}

        <form onSubmit={submit} className="card mt-4 space-y-4 p-6">
          <h2 className="text-lg font-bold">Criar minha carteirinha</h2>
          <div>
            <label className="label" htmlFor="n">Nome</label>
            <input id="n" className="input" required minLength={2} maxLength={80} value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
          </div>
          <div>
            <label className="label" htmlFor="p">WhatsApp</label>
            <input id="p" className="input" required inputMode="tel" placeholder="(31) 99999-9999" value={phone}
              onChange={(e) => setPhone(maskPhone(e.target.value))} autoComplete="tel" />
          </div>
          <div>
            <label className="label" htmlFor="em">E-mail <span className="text-muted">(opcional)</span></label>
            <input id="em" type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
          </div>
          <div>
            <label className="label" htmlFor="b">Aniversário <span className="text-muted">(opcional)</span></label>
            <input id="b" type="date" className="input" value={birthday} onChange={(e) => setBirthday(e.target.value)} />
          </div>
          <label className="flex items-start gap-3 text-sm text-muted">
            <input type="checkbox" className="mt-0.5 h-4 w-4 accent-[#A8843F]" checked={consent} onChange={(e) => setConsent(e.target.checked)} required />
            <span>Autorizo {info.business_name} a guardar meus dados para o programa de fidelidade, conforme a LGPD. Posso pedir a exclusão a qualquer momento.</span>
          </label>
          <Alert>{error}</Alert>
          <button className="btn btn-primary w-full" disabled={busy || !consent}>{busy && <Spinner />} Participar</button>
        </form>
      </main>
    </div>
  );
}

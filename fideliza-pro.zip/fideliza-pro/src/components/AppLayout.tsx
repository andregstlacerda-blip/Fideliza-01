import { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { LayoutDashboard, PlusCircle, Gift, Users, Award, QrCode, Settings, LogOut, Menu, X, AlertTriangle } from 'lucide-react';
import { useSession } from '../lib/session';
import { Logo, ThemeToggle } from './ui';

const items = [
  { to: '/app', label: 'Painel', icon: LayoutDashboard, end: true },
  { to: '/app/pontuar', label: 'Pontuar', icon: PlusCircle },
  { to: '/app/resgatar', label: 'Resgatar', icon: Gift },
  { to: '/app/clientes', label: 'Clientes', icon: Users },
  { to: '/app/recompensas', label: 'Recompensas', icon: Award },
  { to: '/app/qr', label: 'QR do balcão', icon: QrCode },
  { to: '/app/configuracoes', label: 'Configurações', icon: Settings, owner: true },
];

export default function AppLayout() {
  const { business, role, license, signOut } = useSession();
  const [open, setOpen] = useState(false);
  const nav = useNavigate();
  const visible = items.filter((i) => !i.owner || role === 'owner');
  const expired = license && (license.status === 'expired' || license.status === 'blocked' ||
    (license.expires_at && new Date(license.expires_at) < new Date()));
  const trialDays = license?.status === 'trial' && license.expires_at
    ? Math.max(0, Math.ceil((new Date(license.expires_at).getTime() - Date.now()) / 86400000)) : null;

  const link = ({ isActive }: { isActive: boolean }) =>
    `flex items-center gap-3 rounded-xl px-3 h-10 text-sm font-medium transition-colors ${
      isActive ? 'bg-surface-2 text-fg' : 'text-muted hover:text-fg hover:bg-surface-2'}`;

  const out = async () => { await signOut(); nav('/'); };

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[260px_1fr]">
      {/* Sidebar desktop */}
      <aside className="sticky top-0 hidden h-screen flex-col border-r border-line bg-surface p-4 lg:flex">
        <div className="px-2 py-2"><Logo /></div>
        <p className="mt-4 truncate px-3 text-xs font-semibold uppercase tracking-wider text-muted">{business?.name}</p>
        <nav className="mt-2 flex flex-col gap-1">
          {visible.map((i) => (
            <NavLink key={i.to} to={i.to} end={i.end} className={link}><i.icon size={18} /> {i.label}</NavLink>
          ))}
        </nav>
        <div className="mt-auto flex items-center justify-between gap-2 border-t border-line pt-4">
          <button onClick={out} className="flex items-center gap-2 text-sm text-muted hover:text-fg cursor-pointer"><LogOut size={16} /> Sair</button>
          <ThemeToggle />
        </div>
      </aside>

      {/* Topo mobile */}
      <header className="sticky top-0 z-20 flex items-center justify-between border-b border-line bg-bg/90 px-4 py-3 backdrop-blur lg:hidden">
        <Logo size="sm" />
        <button className="grid h-10 w-10 place-items-center rounded-xl border border-line bg-surface cursor-pointer" onClick={() => setOpen(true)} aria-label="Abrir menu"><Menu size={18} /></button>
      </header>

      {open && (
        <div className="fixed inset-0 z-40 lg:hidden" onClick={() => setOpen(false)}>
          <div className="absolute inset-0 bg-black/50" />
          <div className="absolute right-0 top-0 flex h-full w-72 flex-col bg-surface p-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <p className="truncate text-sm font-semibold">{business?.name}</p>
              <button className="grid h-9 w-9 place-items-center cursor-pointer" onClick={() => setOpen(false)} aria-label="Fechar"><X size={18} /></button>
            </div>
            <nav className="mt-4 flex flex-col gap-1">
              {visible.map((i) => (
                <NavLink key={i.to} to={i.to} end={i.end} className={link} onClick={() => setOpen(false)}><i.icon size={18} /> {i.label}</NavLink>
              ))}
            </nav>
            <div className="mt-auto flex items-center justify-between border-t border-line pt-4">
              <button onClick={out} className="flex items-center gap-2 text-sm text-muted cursor-pointer"><LogOut size={16} /> Sair</button>
              <ThemeToggle />
            </div>
          </div>
        </div>
      )}

      <main className="min-w-0 px-4 pb-28 pt-6 sm:px-6 lg:px-10 lg:pb-10 lg:pt-10">
        <div className="mx-auto max-w-5xl">
          {expired && (
            <div className="mb-6 flex items-start gap-2 rounded-xl border border-danger/40 bg-surface p-3 text-sm text-danger">
              <AlertTriangle size={18} className="mt-0.5 shrink-0" />
              Sua licença está inativa ou expirou. Pontuações, resgates e novos cadastros estão bloqueados.
            </div>
          )}
          {!expired && trialDays !== null && role === 'owner' && (
            <div className="mb-6 rounded-xl border border-line bg-surface p-3 text-sm text-muted">
              Período de teste: <strong className="text-fg">{trialDays} {trialDays === 1 ? 'dia restante' : 'dias restantes'}</strong>.
            </div>
          )}
          <Outlet />
        </div>
      </main>

      {/* Barra inferior mobile: ações do balcão */}
      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-4 border-t border-line bg-surface pb-[env(safe-area-inset-bottom)] lg:hidden">
        {items.slice(0, 4).map((i) => (
          <NavLink key={i.to} to={i.to} end={i.end}
            className={({ isActive }) => `flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium ${isActive ? 'text-gold' : 'text-muted'}`}>
            <i.icon size={22} /> {i.label}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}

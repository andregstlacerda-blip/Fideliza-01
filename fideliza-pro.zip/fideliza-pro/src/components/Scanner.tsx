import { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { Camera, CameraOff } from 'lucide-react';

/** Leitor de QR pela câmera traseira. Chama onScan uma vez por leitura. */
export default function Scanner({ onScan, paused = false }: { onScan: (text: string) => void; paused?: boolean }) {
  const ref = useRef<Html5Qrcode | null>(null);
  const cb = useRef(onScan);
  cb.current = onScan;
  const [error, setError] = useState('');
  const [active, setActive] = useState(false);

  useEffect(() => {
    if (paused) return;
    const qr = new Html5Qrcode('qr-reader', { verbose: false });
    ref.current = qr;
    let stopped = false;
    let last = '';
    qr.start(
      { facingMode: 'environment' },
      { fps: 10, qrbox: (w, h) => { const s = Math.floor(Math.min(w, h) * 0.7); return { width: s, height: s }; } },
      (text) => {
        if (text === last) return;
        last = text;
        cb.current(text);
      },
      () => {},
    ).then(() => { if (!stopped) setActive(true); })
      .catch(() => setError('Não foi possível abrir a câmera. Permita o acesso à câmera ou digite o código abaixo.'));
    return () => {
      stopped = true;
      setActive(false);
      if (qr.isScanning) qr.stop().then(() => qr.clear()).catch(() => {});
    };
  }, [paused]);

  return (
    <div className="overflow-hidden rounded-2xl border border-line bg-[#0E0E10]">
      <div id="qr-reader" className="aspect-square w-full" />
      {!active && (
        <div className="flex items-center gap-2 p-4 text-sm text-[#A29C90]">
          {error ? <><CameraOff size={18} /> {error}</> : <><Camera size={18} /> {paused ? 'Leitor pausado' : 'Abrindo câmera…'}</>}
        </div>
      )}
    </div>
  );
}

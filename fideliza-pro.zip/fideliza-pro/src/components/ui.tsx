import { useEffect, useState, type ReactNode } from 'react';
import { Moon, Sun, Loader2, AlertCircle, CheckCircle2 } from 'lucide-react';
import { applyTheme, getTheme, type Theme } from '../lib/theme';

export function Logo({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const box = size === 'lg' ? 'h-11 w-11 text-xl' : size === 'sm' ? 'h-7 w-7 text-sm' : 'h-9 w-9 text-base';
  return (
    <span className="inline-flex items-center gap-2.5">
      <span className={`${box} grid place-items-center rounded-xl bg-[#0E0E10] font-display font-extrabold text-[#C9A050] ring-1 ring-[#C9A050]/30`}>F</span>
      <span className={`font-display font-bold ${size === 'lg' ? 'text-2xl' : 'text-lg'}`}>
        Fideliza <span className="text-gold">Pro</span>
      </span>
    </span>
  );
}

export function ThemeToggle() {
  const [t, setT] = useState<Theme>(getTheme());
  useEffect(() => applyTheme(t), [t]);
  return (
    <button
      className="grid h-10 w-10 place-items-center rounded-xl border border-line bg-surface hover:bg-surface-2 cursor-pointer"
      onClick={() => setT(t === 'dark' ? 'light' : 'dark')}
      aria-label={t === 'dark' ? 'Usar tema claro' : 'Usar tema escuro'}
    >
      {t === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  );
}

export const Spinner = ({ className = '' }: { className?: string }) => (
  <Loader2 className={`animate-spin ${className}`} size={18} />
);

export function PageLoader() {
  return <div className="grid min-h-[50vh] place-items-center text-muted"><Spinner className="h-6 w-6" /></div>;
}

export function Alert({ kind = 'error', children }: { kind?: 'error' | 'success'; children: ReactNode }) {
  if (!children) return null;
  const Icon = kind === 'error' ? AlertCircle : CheckCircle2;
  const color = kind === 'error' ? 'text-danger' : 'text-success';
  return (
    <div role="alert" className={`flex items-start gap-2 rounded-xl border border-line bg-surface-2 p-3 text-sm ${color}`}>
      <Icon size={18} className="mt-0.5 shrink-0" /> <span>{children}</span>
    </div>
  );
}

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-bold sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function Empty({ icon, title, text, action }: { icon: ReactNode; title: string; text: string; action?: ReactNode }) {
  return (
    <div className="card flex flex-col items-center px-6 py-12 text-center">
      <div className="mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-surface-2 text-gold">{icon}</div>
      <h3 className="font-semibold">{title}</h3>
      <p className="mt-1 max-w-sm text-sm text-muted">{text}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Stat({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) {
  return (
    <div className="card p-5">
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-2 font-display text-3xl font-bold">{value}</p>
      {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}
    </div>
  );
}

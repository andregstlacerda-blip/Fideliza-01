import { lazy, Suspense, type ReactNode } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { useSession } from './lib/session';
import { supabaseConfigured } from './lib/supabase';
import { PageLoader } from './components/ui';
import AppLayout from './components/AppLayout';
import Landing from './pages/public/Landing';
import Auth from './pages/public/Auth';
import Join from './pages/public/Join';
import Card from './pages/public/Card';
import Onboarding from './pages/app/Onboarding';
import Dashboard from './pages/app/Dashboard';
import Customers from './pages/app/Customers';
import CustomerDetail from './pages/app/CustomerDetail';
import Rewards from './pages/app/Rewards';
import CounterQR from './pages/app/CounterQR';
import Settings from './pages/app/Settings';

// Telas com leitor de QR carregam a biblioteca da câmera só quando abertas
const Earn = lazy(() => import('./pages/app/Earn'));
const Redeem = lazy(() => import('./pages/app/Redeem'));

function RequireBusiness({ children, ownerOnly = false }: { children: ReactNode; ownerOnly?: boolean }) {
  const { session, loading, business, role } = useSession();
  const loc = useLocation();
  if (loading) return <PageLoader />;
  if (!session) return <Navigate to={`/entrar?voltar=${encodeURIComponent(loc.pathname + loc.search)}`} replace />;
  if (!business) return <Navigate to="/comecar" replace />;
  if (ownerOnly && role !== 'owner') return <Navigate to="/app" replace />;
  return <>{children}</>;
}

export default function App() {
  if (!supabaseConfigured) {
    return (
      <div className="mx-auto max-w-lg p-8">
        <h1 className="text-xl font-bold">Configuração pendente</h1>
        <p className="mt-2 text-sm text-muted">
          Crie o arquivo <code>.env</code> na raiz do projeto com <code>VITE_SUPABASE_URL</code> e{' '}
          <code>VITE_SUPABASE_ANON_KEY</code> (veja o <code>.env.example</code> e o README) e reinicie o <code>npm run dev</code>.
        </p>
      </div>
    );
  }
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/entrar" element={<Auth mode="login" />} />
      <Route path="/cadastro" element={<Auth mode="signup" />} />
      <Route path="/e/:code" element={<Join />} />
      <Route path="/c/:token" element={<Card />} />
      <Route path="/comecar" element={<Onboarding />} />
      <Route path="/app" element={<RequireBusiness><AppLayout /></RequireBusiness>}>
        <Route index element={<Dashboard />} />
        <Route path="pontuar" element={<Suspense fallback={<PageLoader />}><Earn /></Suspense>} />
        <Route path="resgatar" element={<Suspense fallback={<PageLoader />}><Redeem /></Suspense>} />
        <Route path="clientes" element={<Customers />} />
        <Route path="clientes/:id" element={<CustomerDetail />} />
        <Route path="recompensas" element={<Rewards />} />
        <Route path="qr" element={<CounterQR />} />
        <Route path="configuracoes" element={<RequireBusiness ownerOnly><Settings /></RequireBusiness>} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

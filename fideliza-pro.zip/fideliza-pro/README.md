# Fideliza Pro — MVP

Programa de fidelidade digital para pequenos negócios.
React + Vite + Tailwind + Supabase · identidade visual Grafite e Dourado.

## Decisões de produto já implementadas

| Tema | Decisão |
| --- | --- |
| Pontuação | O dono escolhe: **carimbos por visita** ou **pontos por valor gasto** (ex.: R$ 10 = 1 ponto) |
| Cadastro do cliente | **Somente pelo QR Code do balcão** (página pública `/e/CODIGO`) |
| Resgate | Cliente gera um **QR de resgate** (válido por 10 min) na carteirinha; funcionário escaneia e confirma |

## Telas

| Rota | Quem usa | O que faz |
| --- | --- | --- |
| `/` | Público | Página de vendas |
| `/cadastro`, `/entrar` | Dono e funcionário | Conta e login |
| `/comecar` | Dono | Cria o estabelecimento e escolhe carimbos ou pontos (teste de 30 dias) |
| `/app` | Equipe | Painel com indicadores e primeiros passos |
| `/app/pontuar` | Equipe | Lê o QR da carteirinha pela câmera (ou busca por nome/telefone) e pontua |
| `/app/resgatar` | Equipe | Lê o QR de resgate e confirma a entrega |
| `/app/clientes` | Equipe | Lista, busca, histórico, link da carteirinha por WhatsApp; o dono faz ajustes e exclusão (LGPD) |
| `/app/recompensas` | Dono (equipe só vê) | Cria, edita e pausa recompensas |
| `/app/qr` | Equipe | Cartaz do QR do balcão para imprimir |
| `/app/configuracoes` | Dono | Programa, dados, equipe (até 2 funcionários) e licença |
| `/e/:codigo` | Cliente | Cadastro pelo QR do balcão (com consentimento LGPD) |
| `/c/:token` | Cliente | Carteirinha: saldo, QR para pontuar, recompensas, QR de resgate e histórico |

## Segurança (já no banco)

- RLS em todas as tabelas. Cada estabelecimento só enxerga os próprios dados (`business_id`).
- Pontuar, resgatar, cadastrar cliente e convidar equipe acontecem em funções do servidor (`SECURITY DEFINER`), nunca no navegador.
- Pontuação com **idempotência**: um clique duplo não pontua duas vezes.
- Resgate **atômico**: confere o saldo na hora, nunca deixa negativo e não confirma o mesmo código duas vezes.
- O histórico de pontos é **imutável**: correções viram transações de ajuste com motivo. A única exceção é a exclusão do cliente a pedido dele (LGPD).
- Os tokens das carteirinhas são aleatórios (48 caracteres). Os QR Codes não carregam dados pessoais.
- A licença (teste/ativa/expirada) bloqueia pontuação, resgate e novos cadastros quando vence.
- O navegador só usa a chave **anon**. A `service_role` nunca entra no frontend.

A migration foi testada em Postgres com 42 cenários: pontos, carimbos, idempotência, isolamento entre empresas, expiração, saldo insuficiente, permissões de dono e funcionário, licença e exclusão LGPD.

---

# Passo a passo para rodar

## 1. Criar o projeto no Supabase

1. Acesse https://supabase.com e faça login.
2. Clique em **New project**.
3. Nome: `fideliza-pro`. Crie uma senha forte para o banco e guarde-a. Região: **South America (São Paulo)**.
4. Clique em **Create new project** e espere 1 a 2 minutos até ele ficar pronto.

> Use um projeto **exclusivo** para o Fideliza Pro. Não reaproveite o do Horaê.

## 2. Rodar o SQL do banco

1. No menu lateral do Supabase, clique em **SQL Editor**.
2. Clique em **+ New query**.
3. No seu computador, abra o arquivo `supabase/migrations/0001_fideliza_pro.sql` (no VS Code ou Bloco de Notas), aperte **Ctrl+A** e depois **Ctrl+C**.
4. Cole no SQL Editor com **Ctrl+V**.
5. Clique em **Run** (ou aperte **Ctrl+Enter**).
6. Deve aparecer **Success. No rows returned**. Se aparecer erro, copie a mensagem e me mande.
7. Para conferir, clique em **Table Editor**. Devem aparecer as tabelas `businesses`, `customers`, `rewards`, `point_transactions` e as demais.

## 3. Configurar a autenticação

1. Vá em **Authentication → Sign In / Providers → Email** e confirme que **Email** está habilitado.
2. **Durante o desenvolvimento**, para testar mais rápido, você pode desligar **Confirm email**. Em produção, ligue de novo.
3. Vá em **Authentication → URL Configuration**:
   - **Site URL**: `http://localhost:5173` (depois troque pelo domínio do Netlify)
   - Em **Redirect URLs**, adicione `http://localhost:5173/**`

## 4. Pegar as chaves

1. Vá em **Project Settings** (engrenagem) → **API** (ou **Data API**).
2. Copie o **Project URL**, algo como `https://abcd1234.supabase.co`.
3. Copie a chave **anon public** (ou **Publishable key**).
   **Não** copie a `service_role`/secret.

## 5. Rodar no seu computador (CMD)

Pré-requisito: Node.js 20 ou mais recente (`node -v` no CMD para conferir).

1. Extraia o `fideliza-pro.zip` numa pasta, por exemplo `C:\projetos\fideliza-pro`.
2. Abra o **CMD** e entre na pasta:
   ```
   cd C:\projetos\fideliza-pro
   ```
3. Crie o arquivo `.env` a partir do exemplo:
   ```
   copy .env.example .env
   ```
4. Abra o `.env` no VS Code (`code .env`) ou no Bloco de Notas (`notepad .env`) e preencha:
   ```
   VITE_SUPABASE_URL=https://abcd1234.supabase.co
   VITE_SUPABASE_ANON_KEY=sua-chave-anon
   ```
   Salve o arquivo.
5. Instale as dependências (só na primeira vez):
   ```
   npm install
   ```
6. Inicie o projeto:
   ```
   npm run dev
   ```
7. Abra **http://localhost:5173** no navegador.

## 6. Testar o fluxo completo

1. Em **Criar conta**, cadastre-se como dono.
2. Em `/comecar`, crie o estabelecimento e escolha **Carimbos** ou **Pontos**.
3. Em **Recompensas**, crie uma, por exemplo "Corte grátis" por 3 carimbos (custo baixo só para o teste).
4. Em **QR do balcão**, clique em **Copiar link** e abra numa **janela anônima**. Esse é o cliente.
5. Na janela anônima, cadastre-se como cliente. Você cai na carteirinha.
6. Na janela do dono, vá em **Pontuar**, busque o cliente pelo nome e confirme. Faça isso 3 vezes.
7. Atualize a carteirinha (janela anônima). O saldo sobe e o botão **Resgatar** fica disponível.
8. Clique em **Resgatar**. Aparece o QR e o código de 8 letras.
9. Na janela do dono, vá em **Resgatar**, digite o código e clique em **Confirmar e entregar**.
10. Em poucos segundos, a carteirinha mostra "resgatado" e o saldo novo.

### Testar a câmera no celular

A câmera só funciona em **HTTPS** ou em `localhost`. No celular, a forma mais fácil é testar depois do deploy no Netlify (passo 7). Pelo celular:

- O cliente escaneia o QR do balcão com a câmera do celular.
- O funcionário abre `/app/pontuar` no celular dele e aponta para o QR da carteirinha do cliente.

### Funcionário

1. O dono vai em **Configurações → Equipe** e convida o e-mail do funcionário.
2. O funcionário cria a conta em `/cadastro` **com esse mesmo e-mail** e já cai no painel do estabelecimento.

## 7. Deploy no Netlify

1. Crie um repositório **novo e exclusivo** no GitHub. No CMD, dentro da pasta:
   ```
   git init
   git add .
   git commit -m "Fideliza Pro MVP"
   git branch -M main
   git remote add origin https://github.com/SEU-USUARIO/fideliza-pro.git
   git push -u origin main
   ```
   O `.env` não sobe, porque está no `.gitignore`.
2. No Netlify: **Add new site → Import an existing project → GitHub →** escolha `fideliza-pro`.
3. Configure:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
4. Em **Environment variables**, adicione `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` com os mesmos valores do `.env`.
5. Clique em **Deploy**.
6. Volte no Supabase, em **Authentication → URL Configuration**:
   - Troque o **Site URL** para a URL do Netlify (ex.: `https://fideliza-pro.netlify.app`)
   - Adicione `https://fideliza-pro.netlify.app/**` em **Redirect URLs**

O arquivo `public/_redirects` já faz as rotas (`/app`, `/c/...`, `/e/...`) funcionarem no Netlify.

---

## O que ainda falta (próximas etapas)

- **Pagamento (R$ 97):** escolher entre Mercado Pago e Kiwify, depois criar a Edge Function de webhook que valida a compra e ativa a licença (`licenses.status = 'active'`). Por enquanto, todo estabelecimento novo ganha 30 dias de teste. Para liberar um piloto manualmente, rode no SQL Editor:
  ```sql
  update licenses set status = 'active', expires_at = null
  where business_id = (select id from businesses where name = 'Nome do Estabelecimento');
  ```
- **Termos de uso e política de privacidade** (necessários para o cadastro com LGPD).
- **Definir por escrito** o que os R$ 97 incluem: tempo de hospedagem, suporte e atualizações.
- **Limite de cadastros por minuto** na página pública, se aparecer abuso.
- V2 do plano: campanhas, aniversariantes, cupons, WhatsApp.

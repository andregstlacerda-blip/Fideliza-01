-- =====================================================================
-- Fideliza Pro — migration inicial
-- Decisões de produto:
--   * Pontuação: o dono escolhe entre PONTOS por valor gasto ou CARIMBOS por visita
--   * Cadastro do cliente: SOMENTE pelo QR Code do estabelecimento (página pública)
--   * Resgate: cliente gera um QR de resgate na carteirinha; funcionário escaneia e confirma
-- Segurança:
--   * RLS em todas as tabelas; isolamento por business_id
--   * Pontuação e resgate apenas via funções SECURITY DEFINER (atômicas, com idempotência)
--   * Histórico de pontos imutável (sem UPDATE/DELETE)
-- Rode este arquivo inteiro no SQL Editor do Supabase.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- Utilitário: token aleatório não previsível
-- ---------------------------------------------------------------------
create or replace function public.random_code(len int, alphabet text default 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789')
returns text language plpgsql volatile as $$
declare
  bytes bytea := gen_random_bytes(len);
  result text := '';
  i int;
begin
  for i in 0 .. len - 1 loop
    result := result || substr(alphabet, (get_byte(bytes, i) % length(alphabet)) + 1, 1);
  end loop;
  return result;
end $$;

-- ---------------------------------------------------------------------
-- Tabelas
-- ---------------------------------------------------------------------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  created_at timestamptz not null default now()
);

create table public.businesses (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 80),
  segment text,
  phone text,
  join_code text not null unique default public.random_code(12),
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.business_members (
  business_id uuid not null references public.businesses(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner', 'staff')),
  created_at timestamptz not null default now(),
  primary key (business_id, user_id)
);
create index on public.business_members (user_id);

create table public.staff_invites (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  email text not null,
  created_by uuid not null references auth.users(id),
  accepted_at timestamptz,
  accepted_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (business_id, email)
);

create table public.licenses (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null unique references public.businesses(id) on delete cascade,
  status text not null default 'trial' check (status in ('trial', 'active', 'expired', 'blocked')),
  max_customers int not null default 500,
  max_staff int not null default 2,
  max_programs int not null default 1,
  expires_at timestamptz,
  payment_provider text,
  payment_ref text unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.loyalty_programs (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null unique references public.businesses(id) on delete cascade,
  name text not null default 'Programa de fidelidade',
  mode text not null default 'points' check (mode in ('points', 'stamps')),
  amount_per_point numeric(10,2) not null default 10 check (amount_per_point > 0), -- R$ gastos para 1 ponto
  stamps_per_visit int not null default 1 check (stamps_per_visit between 1 and 10),
  welcome_message text,
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

create table public.customers (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 80),
  phone text not null check (phone ~ '^[0-9]{10,13}$'),
  email text,
  birthday date,
  consent_at timestamptz not null,
  created_at timestamptz not null default now(),
  unique (business_id, phone)
);
create index on public.customers (business_id, created_at desc);

create table public.customer_cards (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  customer_id uuid not null unique references public.customers(id) on delete cascade,
  token text not null unique default encode(gen_random_bytes(24), 'hex'),
  created_at timestamptz not null default now()
);

create table public.rewards (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 80),
  description text,
  cost int not null check (cost > 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create index on public.rewards (business_id);

create table public.redemptions (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  customer_id uuid not null references public.customers(id) on delete cascade,
  reward_id uuid not null references public.rewards(id),
  reward_name text not null,
  cost int not null,
  code text not null unique default public.random_code(8),
  status text not null default 'pending' check (status in ('pending', 'confirmed', 'expired', 'cancelled')),
  expires_at timestamptz not null default now() + interval '10 minutes',
  confirmed_by uuid references auth.users(id),
  confirmed_at timestamptz,
  created_at timestamptz not null default now()
);
create index on public.redemptions (business_id, created_at desc);
create index on public.redemptions (customer_id, status);

create table public.point_transactions (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  customer_id uuid not null references public.customers(id) on delete cascade,
  kind text not null check (kind in ('earn', 'redeem', 'adjust')),
  points int not null check (points <> 0),
  amount numeric(10,2),
  redemption_id uuid unique references public.redemptions(id) on delete set null,
  idempotency_key text,
  note text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  unique (business_id, idempotency_key)
);
create index on public.point_transactions (customer_id);
create index on public.point_transactions (business_id, created_at desc);

create table public.activity_logs (
  id bigint generated always as identity primary key,
  business_id uuid not null references public.businesses(id) on delete cascade,
  actor_id uuid references auth.users(id),
  action text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index on public.activity_logs (business_id, created_at desc);

-- Histórico de pontos é imutável
create or replace function public.block_mutation() returns trigger language plpgsql as $$
begin
  -- Única exceção: exclusão do cliente (pedido LGPD) apaga o histórico em cascata
  if not exists (select 1 from public.customers where id = old.customer_id) then
    if tg_op = 'DELETE' then return old; end if;
    return new;
  end if;
  raise exception 'Histórico imutável: registre uma transação compensatória.';
end $$;
create trigger point_transactions_immutable
  before update or delete on public.point_transactions
  for each row execute function public.block_mutation();

-- ---------------------------------------------------------------------
-- Helpers de permissão (usados nas políticas RLS)
-- ---------------------------------------------------------------------
create or replace function public.is_member(bid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from business_members where business_id = bid and user_id = auth.uid());
$$;

create or replace function public.is_owner(bid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from business_members where business_id = bid and user_id = auth.uid() and role = 'owner');
$$;

create or replace function public.license_ok(bid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from licenses
    where business_id = bid and status in ('trial', 'active')
      and (expires_at is null or expires_at > now())
  );
$$;

create or replace function public.customer_balance(cid uuid) returns int
language sql stable security definer set search_path = public as $$
  select coalesce(sum(points), 0)::int from point_transactions where customer_id = cid;
$$;

create or replace function public.log_activity(bid uuid, act text, det jsonb) returns void
language sql security definer set search_path = public as $$
  insert into activity_logs (business_id, actor_id, action, details) values (bid, auth.uid(), act, coalesce(det, '{}'::jsonb));
$$;

-- ---------------------------------------------------------------------
-- RLS
-- ---------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.businesses enable row level security;
alter table public.business_members enable row level security;
alter table public.staff_invites enable row level security;
alter table public.licenses enable row level security;
alter table public.loyalty_programs enable row level security;
alter table public.customers enable row level security;
alter table public.customer_cards enable row level security;
alter table public.rewards enable row level security;
alter table public.redemptions enable row level security;
alter table public.point_transactions enable row level security;
alter table public.activity_logs enable row level security;

-- profiles: cada um vê e edita o próprio
create policy "profiles_self_select" on public.profiles for select using (id = auth.uid());
create policy "profiles_self_insert" on public.profiles for insert with check (id = auth.uid());
create policy "profiles_self_update" on public.profiles for update using (id = auth.uid());

-- businesses: membros leem; dono edita. Criação só via create_business()
create policy "businesses_member_select" on public.businesses for select using (public.is_member(id));
create policy "businesses_owner_update" on public.businesses for update using (public.is_owner(id)) with check (public.is_owner(id));

-- members: membros veem a equipe; dono remove funcionários (não a si mesmo)
create policy "members_select" on public.business_members for select using (public.is_member(business_id));
create policy "members_owner_delete" on public.business_members for delete
  using (public.is_owner(business_id) and role = 'staff');

-- invites: só o dono
create policy "invites_owner_all" on public.staff_invites for all
  using (public.is_owner(business_id)) with check (public.is_owner(business_id) and created_by = auth.uid());

-- licenses: membros leem; alteração só pelo servidor (service_role / webhook)
create policy "licenses_member_select" on public.licenses for select using (public.is_member(business_id));

-- programa: membros leem, dono edita
create policy "programs_member_select" on public.loyalty_programs for select using (public.is_member(business_id));
create policy "programs_owner_update" on public.loyalty_programs for update
  using (public.is_owner(business_id)) with check (public.is_owner(business_id));

-- clientes: membros leem e editam; inserção só via join_business() (QR)
create policy "customers_member_select" on public.customers for select using (public.is_member(business_id));
create policy "customers_member_update" on public.customers for update
  using (public.is_member(business_id)) with check (public.is_member(business_id));
create policy "customers_owner_delete" on public.customers for delete using (public.is_owner(business_id));

create policy "cards_member_select" on public.customer_cards for select using (public.is_member(business_id));

-- recompensas: membros leem; dono gerencia
create policy "rewards_member_select" on public.rewards for select using (public.is_member(business_id));
create policy "rewards_owner_insert" on public.rewards for insert with check (public.is_owner(business_id));
create policy "rewards_owner_update" on public.rewards for update
  using (public.is_owner(business_id)) with check (public.is_owner(business_id));

-- resgates, transações e logs: somente leitura para membros
create policy "redemptions_member_select" on public.redemptions for select using (public.is_member(business_id));
create policy "transactions_member_select" on public.point_transactions for select using (public.is_member(business_id));
create policy "logs_owner_select" on public.activity_logs for select using (public.is_owner(business_id));

-- ---------------------------------------------------------------------
-- Perfil automático ao cadastrar usuário
-- ---------------------------------------------------------------------
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, full_name) values (new.id, new.raw_user_meta_data->>'full_name')
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- RPC: estabelecimento e equipe
-- ---------------------------------------------------------------------
create or replace function public.create_business(p_name text, p_segment text default null, p_phone text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare bid uuid;
begin
  if auth.uid() is null then raise exception 'Não autenticado'; end if;
  if exists (select 1 from business_members where user_id = auth.uid()) then
    raise exception 'Sua conta já está vinculada a um estabelecimento.';
  end if;
  insert into businesses (name, segment, phone, created_by)
    values (trim(p_name), p_segment, p_phone, auth.uid()) returning id into bid;
  insert into business_members (business_id, user_id, role) values (bid, auth.uid(), 'owner');
  insert into licenses (business_id, status, expires_at) values (bid, 'trial', now() + interval '30 days');
  insert into loyalty_programs (business_id) values (bid);
  perform log_activity(bid, 'business.created', jsonb_build_object('name', p_name));
  return bid;
end $$;

create or replace function public.claim_invites() returns int
language plpgsql security definer set search_path = public as $$
declare inv record; n int := 0; staff_count int; lim int;
begin
  if auth.uid() is null then return 0; end if;
  for inv in
    select * from staff_invites
    where lower(email) = lower(auth.jwt()->>'email') and accepted_at is null
    for update
  loop
    if exists (select 1 from business_members where user_id = auth.uid()) then exit; end if;
    select count(*) into staff_count from business_members where business_id = inv.business_id and role = 'staff';
    select max_staff into lim from licenses where business_id = inv.business_id;
    if staff_count < coalesce(lim, 2) then
      insert into business_members (business_id, user_id, role) values (inv.business_id, auth.uid(), 'staff');
      update staff_invites set accepted_at = now(), accepted_by = auth.uid() where id = inv.id;
      perform log_activity(inv.business_id, 'staff.joined', jsonb_build_object('email', inv.email));
      n := n + 1;
    end if;
  end loop;
  return n;
end $$;

create or replace function public.invite_staff(p_business uuid, p_email text) returns void
language plpgsql security definer set search_path = public as $$
declare staff_count int; pending int; lim int;
begin
  if not is_owner(p_business) then raise exception 'Apenas o proprietário pode convidar.'; end if;
  select count(*) into staff_count from business_members where business_id = p_business and role = 'staff';
  select count(*) into pending from staff_invites where business_id = p_business and accepted_at is null;
  select max_staff into lim from licenses where business_id = p_business;
  if staff_count + pending >= coalesce(lim, 2) then
    raise exception 'Limite de % funcionários da licença atingido.', coalesce(lim, 2);
  end if;
  insert into staff_invites (business_id, email, created_by) values (p_business, lower(trim(p_email)), auth.uid());
  perform log_activity(p_business, 'staff.invited', jsonb_build_object('email', p_email));
end $$;

create or replace function public.remove_staff(p_invite uuid) returns void
language plpgsql security definer set search_path = public as $$
declare inv record;
begin
  select * into inv from staff_invites where id = p_invite;
  if inv.id is null or not is_owner(inv.business_id) then raise exception 'Convite não encontrado.'; end if;
  if inv.accepted_by is not null then
    delete from business_members where business_id = inv.business_id and user_id = inv.accepted_by and role = 'staff';
  end if;
  delete from staff_invites where id = inv.id;
  perform log_activity(inv.business_id, 'staff.removed', jsonb_build_object('email', inv.email));
end $$;

-- ---------------------------------------------------------------------
-- RPC pública: cadastro do cliente pelo QR do estabelecimento
-- ---------------------------------------------------------------------
create or replace function public.get_join_info(p_join_code text)
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'business_name', b.name,
    'segment', b.segment,
    'mode', p.mode,
    'amount_per_point', p.amount_per_point,
    'stamps_per_visit', p.stamps_per_visit,
    'welcome_message', p.welcome_message,
    'rewards', coalesce((select json_agg(json_build_object('name', r.name, 'cost', r.cost) order by r.cost)
                         from rewards r where r.business_id = b.id and r.active), '[]'::json)
  )
  from businesses b join loyalty_programs p on p.business_id = b.id
  where b.join_code = upper(p_join_code);
$$;

create or replace function public.join_business(
  p_join_code text, p_name text, p_phone text, p_email text default null,
  p_birthday date default null, p_consent boolean default false
) returns text language plpgsql security definer set search_path = public as $$
declare b record; cid uuid; tok text; phone_clean text; total int; lim int;
begin
  select * into b from businesses where join_code = upper(p_join_code);
  if b.id is null then raise exception 'Estabelecimento não encontrado.'; end if;
  if not license_ok(b.id) then raise exception 'Este programa de fidelidade não está ativo no momento.'; end if;
  if not coalesce(p_consent, false) then raise exception 'É necessário aceitar os termos para participar.'; end if;

  phone_clean := regexp_replace(coalesce(p_phone, ''), '\D', '', 'g');
  if phone_clean !~ '^[0-9]{10,13}$' then raise exception 'Telefone inválido.'; end if;

  if exists (select 1 from customers where business_id = b.id and phone = phone_clean) then
    raise exception 'Este telefone já participa. Peça ao estabelecimento o link da sua carteirinha.';
  end if;

  select count(*) into total from customers where business_id = b.id;
  select max_customers into lim from licenses where business_id = b.id;
  if total >= coalesce(lim, 500) then raise exception 'O programa atingiu o limite de participantes.'; end if;

  insert into customers (business_id, name, phone, email, birthday, consent_at)
    values (b.id, trim(p_name), phone_clean, nullif(trim(coalesce(p_email, '')), ''), p_birthday, now())
    returning id into cid;
  insert into customer_cards (business_id, customer_id) values (b.id, cid) returning token into tok;
  perform log_activity(b.id, 'customer.joined', jsonb_build_object('customer_id', cid));
  return tok;
end $$;

-- ---------------------------------------------------------------------
-- RPC pública: carteirinha do cliente (acesso pelo token secreto)
-- ---------------------------------------------------------------------
create or replace function public.get_card(p_token text)
returns json language plpgsql security definer set search_path = public as $$
declare c record; result json;
begin
  select cc.customer_id, cc.business_id, cu.name, b.name as business_name
    into c
    from customer_cards cc join customers cu on cu.id = cc.customer_id join businesses b on b.id = cc.business_id
   where cc.token = p_token;
  if c.customer_id is null then return null; end if;

  update redemptions set status = 'expired'
   where customer_id = c.customer_id and status = 'pending' and expires_at <= now();

  select json_build_object(
    'customer_name', split_part(c.name, ' ', 1),
    'business_name', c.business_name,
    'mode', p.mode,
    'amount_per_point', p.amount_per_point,
    'stamps_per_visit', p.stamps_per_visit,
    'balance', customer_balance(c.customer_id),
    'rewards', coalesce((select json_agg(json_build_object('id', r.id, 'name', r.name, 'description', r.description, 'cost', r.cost) order by r.cost)
                         from rewards r where r.business_id = c.business_id and r.active), '[]'::json),
    'pending', (select json_build_object('code', rd.code, 'reward_name', rd.reward_name, 'cost', rd.cost, 'expires_at', rd.expires_at)
                  from redemptions rd where rd.customer_id = c.customer_id and rd.status = 'pending'
                  order by rd.created_at desc limit 1),
    'history', coalesce((select json_agg(h) from (
                  select kind, points, created_at from point_transactions
                   where customer_id = c.customer_id order by created_at desc limit 15) h), '[]'::json)
  ) into result
  from loyalty_programs p where p.business_id = c.business_id;
  return result;
end $$;

-- Cliente gera o código/QR de resgate (não debita; o débito acontece na confirmação)
create or replace function public.request_redemption(p_token text, p_reward uuid)
returns json language plpgsql security definer set search_path = public as $$
declare c record; r record; bal int; rd record;
begin
  select cc.customer_id, cc.business_id into c from customer_cards cc where cc.token = p_token;
  if c.customer_id is null then raise exception 'Carteirinha não encontrada.'; end if;
  if not license_ok(c.business_id) then raise exception 'Programa indisponível no momento.'; end if;

  select * into r from rewards where id = p_reward and business_id = c.business_id and active;
  if r.id is null then raise exception 'Recompensa indisponível.'; end if;

  bal := customer_balance(c.customer_id);
  if bal < r.cost then raise exception 'Saldo insuficiente para esta recompensa.'; end if;

  update redemptions set status = 'cancelled'
   where customer_id = c.customer_id and status = 'pending';

  insert into redemptions (business_id, customer_id, reward_id, reward_name, cost)
    values (c.business_id, c.customer_id, r.id, r.name, r.cost) returning * into rd;
  return json_build_object('code', rd.code, 'reward_name', rd.reward_name, 'cost', rd.cost, 'expires_at', rd.expires_at);
end $$;

create or replace function public.cancel_redemption(p_token text)
returns void language plpgsql security definer set search_path = public as $$
begin
  update redemptions rd set status = 'cancelled'
    from customer_cards cc
   where cc.token = p_token and rd.customer_id = cc.customer_id and rd.status = 'pending';
end $$;

-- ---------------------------------------------------------------------
-- RPC da equipe: pontuar e confirmar resgate (atômicas e idempotentes)
-- ---------------------------------------------------------------------
create or replace function public.earn_points(p_card_token text, p_amount numeric, p_idempotency_key text)
returns json language plpgsql security definer set search_path = public as $$
declare c record; p record; pts int; existing record; bal int;
begin
  if auth.uid() is null then raise exception 'Não autenticado'; end if;
  select cc.customer_id, cc.business_id, cu.name into c
    from customer_cards cc join customers cu on cu.id = cc.customer_id
   where cc.token = p_card_token;
  if c.customer_id is null then raise exception 'Carteirinha não encontrada.'; end if;
  if not is_member(c.business_id) then raise exception 'Esta carteirinha é de outro estabelecimento.'; end if;
  if not license_ok(c.business_id) then raise exception 'Licença inativa ou expirada.'; end if;

  -- idempotência: mesma chave = mesma operação, não pontua duas vezes
  select * into existing from point_transactions
   where business_id = c.business_id and idempotency_key = p_idempotency_key;
  if existing.id is not null then
    return json_build_object('points', existing.points, 'balance', customer_balance(c.customer_id),
                             'customer_name', c.name, 'duplicate', true);
  end if;

  perform 1 from customers where id = c.customer_id for update; -- serializa por cliente
  select * into p from loyalty_programs where business_id = c.business_id;
  if not p.active then raise exception 'Programa de fidelidade pausado.'; end if;

  if p.mode = 'points' then
    if p_amount is null or p_amount <= 0 or p_amount > 100000 then raise exception 'Informe um valor válido.'; end if;
    pts := floor(p_amount / p.amount_per_point);
    if pts < 1 then
      raise exception 'Valor abaixo do mínimo para 1 ponto (R$ %).', to_char(p.amount_per_point, 'FM999990D00');
    end if;
  else
    pts := p.stamps_per_visit;
  end if;

  insert into point_transactions (business_id, customer_id, kind, points, amount, idempotency_key, created_by)
    values (c.business_id, c.customer_id, 'earn', pts,
            case when p.mode = 'points' then p_amount end, p_idempotency_key, auth.uid());
  bal := customer_balance(c.customer_id);
  perform log_activity(c.business_id, 'points.earned',
    jsonb_build_object('customer_id', c.customer_id, 'points', pts, 'amount', p_amount));
  return json_build_object('points', pts, 'balance', bal, 'customer_name', c.name, 'duplicate', false);
end $$;

create or replace function public.preview_redemption(p_code text)
returns json language plpgsql security definer set search_path = public as $$
declare rd record;
begin
  select rd2.*, cu.name as customer_name into rd
    from redemptions rd2 join customers cu on cu.id = rd2.customer_id
   where rd2.code = upper(trim(p_code));
  if rd.id is null or not is_member(rd.business_id) then raise exception 'Código de resgate não encontrado.'; end if;
  return json_build_object('code', rd.code, 'reward_name', rd.reward_name, 'cost', rd.cost,
    'customer_name', rd.customer_name,
    'status', case when rd.status = 'pending' and rd.expires_at <= now() then 'expired' else rd.status end,
    'balance', customer_balance(rd.customer_id), 'expires_at', rd.expires_at);
end $$;

create or replace function public.confirm_redemption(p_code text)
returns json language plpgsql security definer set search_path = public as $$
declare rd record; bal int; cname text;
begin
  if auth.uid() is null then raise exception 'Não autenticado'; end if;
  select * into rd from redemptions where code = upper(trim(p_code)) for update;
  if rd.id is null or not is_member(rd.business_id) then raise exception 'Código de resgate não encontrado.'; end if;
  select name into cname from customers where id = rd.customer_id for update; -- trava o saldo do cliente

  if rd.status = 'confirmed' then
    return json_build_object('reward_name', rd.reward_name, 'customer_name', cname,
                             'balance', customer_balance(rd.customer_id), 'duplicate', true);
  end if;
  if rd.status <> 'pending' then raise exception 'Este resgate foi cancelado ou já expirou.'; end if;
  if rd.expires_at <= now() then
    update redemptions set status = 'expired' where id = rd.id;
    raise exception 'Código expirado. Peça ao cliente para gerar um novo.';
  end if;
  if not license_ok(rd.business_id) then raise exception 'Licença inativa ou expirada.'; end if;

  bal := customer_balance(rd.customer_id);
  if bal < rd.cost then raise exception 'Saldo insuficiente (% de %).', bal, rd.cost; end if;

  insert into point_transactions (business_id, customer_id, kind, points, redemption_id, created_by, note)
    values (rd.business_id, rd.customer_id, 'redeem', -rd.cost, rd.id, auth.uid(), rd.reward_name);
  update redemptions set status = 'confirmed', confirmed_by = auth.uid(), confirmed_at = now() where id = rd.id;
  perform log_activity(rd.business_id, 'redemption.confirmed',
    jsonb_build_object('redemption_id', rd.id, 'customer_id', rd.customer_id, 'cost', rd.cost));
  return json_build_object('reward_name', rd.reward_name, 'customer_name', cname,
                           'balance', bal - rd.cost, 'duplicate', false);
end $$;

-- Ajuste manual (somente dono): transação compensatória com motivo
create or replace function public.adjust_points(p_customer uuid, p_points int, p_note text)
returns int language plpgsql security definer set search_path = public as $$
declare bid uuid; bal int;
begin
  select business_id into bid from customers where id = p_customer for update;
  if bid is null or not is_owner(bid) then raise exception 'Apenas o proprietário pode ajustar pontos.'; end if;
  if p_points = 0 or coalesce(trim(p_note), '') = '' then raise exception 'Informe pontos e motivo.'; end if;
  bal := customer_balance(p_customer);
  if bal + p_points < 0 then raise exception 'O ajuste deixaria o saldo negativo.'; end if;
  insert into point_transactions (business_id, customer_id, kind, points, note, created_by)
    values (bid, p_customer, 'adjust', p_points, p_note, auth.uid());
  perform log_activity(bid, 'points.adjusted', jsonb_build_object('customer_id', p_customer, 'points', p_points, 'note', p_note));
  return bal + p_points;
end $$;

-- ---------------------------------------------------------------------
-- Leituras agregadas para o painel
-- ---------------------------------------------------------------------
create or replace function public.dashboard_stats(p_business uuid)
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not is_member(p_business) then raise exception 'Sem acesso.'; end if;
  return json_build_object(
    'customers', (select count(*) from customers where business_id = p_business),
    'customers_30d', (select count(*) from customers where business_id = p_business and created_at > now() - interval '30 days'),
    'points_issued_30d', (select coalesce(sum(points), 0) from point_transactions where business_id = p_business and kind = 'earn' and created_at > now() - interval '30 days'),
    'redemptions_30d', (select count(*) from redemptions where business_id = p_business and status = 'confirmed' and confirmed_at > now() - interval '30 days'),
    'active_customers_30d', (select count(distinct customer_id) from point_transactions where business_id = p_business and kind = 'earn' and created_at > now() - interval '30 days'),
    'top_customers', coalesce((select json_agg(t) from (
        select cu.id, cu.name, coalesce(sum(pt.points), 0)::int as balance
          from customers cu left join point_transactions pt on pt.customer_id = cu.id
         where cu.business_id = p_business group by cu.id order by balance desc limit 5) t), '[]'::json)
  );
end $$;

create or replace function public.customers_with_balance(p_business uuid, p_search text default null)
returns table (id uuid, name text, phone text, email text, birthday date, created_at timestamptz, balance int, last_visit timestamptz)
language sql stable security definer set search_path = public as $$
  select cu.id, cu.name, cu.phone, cu.email, cu.birthday, cu.created_at,
         coalesce(sum(pt.points), 0)::int,
         max(pt.created_at) filter (where pt.kind = 'earn')
    from customers cu left join point_transactions pt on pt.customer_id = cu.id
   where cu.business_id = p_business and is_member(p_business)
     and (p_search is null or p_search = '' or cu.name ilike '%' || p_search || '%'
          or cu.phone like '%' || regexp_replace(p_search, '\D', '', 'g') || '%')
   group by cu.id
   order by cu.created_at desc
   limit 200;
$$;

-- ---------------------------------------------------------------------
-- Permissões de execução
-- ---------------------------------------------------------------------
revoke execute on all functions in schema public from public, anon;
grant execute on function public.get_join_info(text) to anon, authenticated;
grant execute on function public.join_business(text, text, text, text, date, boolean) to anon, authenticated;
grant execute on function public.get_card(text) to anon, authenticated;
grant execute on function public.request_redemption(text, uuid) to anon, authenticated;
grant execute on function public.cancel_redemption(text) to anon, authenticated;
grant execute on function
  public.is_member(uuid), public.is_owner(uuid), public.license_ok(uuid),
  public.create_business(text, text, text), public.claim_invites(), public.invite_staff(uuid, text), public.remove_staff(uuid),
  public.earn_points(text, numeric, text), public.preview_redemption(text), public.confirm_redemption(text),
  public.adjust_points(uuid, int, text), public.dashboard_stats(uuid), public.customers_with_balance(uuid, text)
  to authenticated;
-- random_code é usado nos DEFAULTs das tabelas; quem insere são funções SECURITY DEFINER
grant execute on function public.random_code(int, text) to authenticated;
